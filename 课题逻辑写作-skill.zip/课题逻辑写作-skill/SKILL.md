---
name: proposal-writing
type: standard
description: >
  多Agent协作撰写科研项目课题申报书的工作流。覆盖选题依据、研究现状、研究内容、
  研究重点、研究难点、研究方法、可行性、创新之处、研究基础、参考文献十大模块。
  采用"调研→方案→论证→整合"四阶段流水线，确保逻辑自洽、前后一致、学术规范。
---

# 课题申报书多Agent协作撰写工作流

## 核心设计理念

课题申报书的10个模块构成一条严密的**逻辑链**：

```
选题依据（贩卖焦虑）→ 研究现状（找卡点）→ 研究内容（解决方案）
  → 研究重点（关键内容）→ 研究难点（重点中的难点）→ 研究方法（解决卡点的方法）
    → 可行性（条件支撑）→ 创新之处（相比过去的推进）→ 研究基础（我的经验）
      → 参考文献（与谁为伍）
```

**设计原则**：
1. **调研先行** — 先完成文献和痛点调研，再动笔写方案
2. **依赖驱动** — 严格按逻辑依赖关系分阶段，上游输出是下游输入
3. **专业分工** — 每个模块由专门Agent负责，确保深度和质量
4. **交叉验证** — 关键模块由评审Agent检查逻辑一致性
5. **一切是文件** — 所有中间产物保存为文件，便于追溯和修改
6. **方法论支撑** — 工作流内置课题申报书撰写方法论参考文献库，各Agent撰写时可参考成熟经验

---

## 输出目录

所有工作流产物保存在：

```
{workspace}/proposal/
```

子目录结构：
```
{workspace}/proposal/
  ├── brief.md              # 阶段0：课题Brief
  ├── research/
  │   ├── pain_analysis.md  # 痛点调研报告
  │   ├── literature_review.md # 文献梳理与卡点分析
  │   └── references.md      # 参考文献清单
  ├── draft/
  │   ├── sec01_rationale.md    # 选题依据
  │   ├── sec02_status.md       # 研究现状
  │   ├── sec03_content.md      # 研究内容
  │   ├── sec04_keypoints.md    # 研究重点
  │   ├── sec05_difficulties.md # 研究难点
  │   ├── sec06_methods.md      # 研究方法
  │   ├── sec07_feasibility.md  # 可行性
  │   ├── sec08_innovation.md   # 创新之处
  │   ├── sec09_foundation.md   # 研究基础
  │   └── sec10_references.md   # 参考文献
  ├── review/
  │   ├── logic_check.md     # 逻辑一致性检查
  │   └── quality_review.md  # 质量评审报告
  └── final/
      └── proposal.agent.final.md  # 最终合并稿
```

---

## 阶段划分与Agent部署

### 阶段0：课题Brief构建（Orchestrator + 用户）

**目标**：明确课题方向、边界、核心问题，形成可执行的Brief。

**过程**：
1. Orchestrator与用户对话，收集以下信息：
   - 课题大方向/领域
   - 初步的研究问题或假设
   - 目标资助机构（如国自然、教育部、省市基金等）
   - 已有的前期成果或素材
   - 研究团队背景
   - 字数/格式要求
2. 整理为结构化Brief，保存至 `{workspace}/proposal/brief.md`

**Brief模板**：
```markdown
# 课题Brief

## 基本信息
- 课题方向：
- 目标资助机构：
- 预计字数：

## 核心研究问题
- 主问题：
- 子问题1：
- 子问题2：

## 已知信息
- 已有素材：
- 前期成果：
- 团队背景：

## 特殊要求
- 格式规范：
- 重点强调：
```

**参考文献库**：本工作流内置课题申报书撰写方法论参考文献库，位于 `{skill_path}/references.md`，涵盖国自然/教育部/社科基金申报实战经验和国际基金申请最佳实践。各Agent在撰写对应模块时可参考相关文献的方法论指导。

---

### 阶段1：调研与发现（并行探索Agent）

**目标**：完成痛点调研、文献梳理、参考文献收集，为后续写作提供素材。

**并行部署3个探索Agent**（`subagent_type="explore"`）：

#### Agent 1: 痛点分析师 — 选题依据素材

**使命**：从社会、政策、行业、学术四个维度搜索痛点证据。

**输入**：`{workspace}/proposal/brief.md`

**参考**：`{skill_path}/references.md` 中"选题依据/立项依据"分类下的文献 [1], [8], [9], [15], [16]，学习"贩卖焦虑"策略的数据开场、政策关联、学术需求、价值升华等方法论。

**任务**：
1. 搜索该领域的社会痛点（新闻、政策文件、行业报告）
2. 搜索相关政策背景（国家政策、地方政策、行业规划）
3. 搜索该领域的紧迫性数据（统计数字、案例）
4. 提炼3-5个核心痛点，每个痛点配证据

**输出**：保存至 `{workspace}/proposal/research/pain_analysis.md`

**输出格式**：
```markdown
# 痛点调研报告

## 痛点1：[名称]
- 描述：
- 证据来源：[^id]
- 数据支撑：
- 政策关联：

## 痛点2：[名称]
...

## 综合建议
- 最适合作为选题依据切入点的痛点：
- 理由：
```

#### Agent 2: 文献调研员 — 研究现状与卡点

**使命**：系统梳理文献，找到现有研究的关键瓶颈（卡点）。

**输入**：`{workspace}/proposal/brief.md`

**参考**：`{skill_path}/references.md` 中"研究现状/文献综述"分类下的文献 [1], [6], [9], [10], [14], [16], [18]，学习"找卡点"策略的脉络组织、批判分析、指出不足、自然衔接等方法论。

**任务**：
1. 搜索该领域近5年核心文献（≥10篇）
2. 按研究脉络分类梳理（理论线、方法线、应用线）
3. 识别每个脉络中的研究进展和空白
4. 提炼3-5个关键卡点（现有研究无法解决的问题）
5. 分析每个卡点的成因和影响

**输出**：保存至 `{workspace}/proposal/research/literature_review.md`

**输出格式**：
```markdown
# 文献梳理与卡点分析

## 研究脉络1：[名称]
- 代表性研究：
- 进展总结：
- 遗留问题：

## 关键卡点
### 卡点1：[名称]
- 描述：
- 现有研究为何无法解决：
- 解决该卡点的价值：
- 相关文献：[^id]

### 卡点2：[名称]
...

## 卡点与课题的关联
- 本课题拟解决的卡点：
- 解决路径：
```

#### Agent 3: 参考文献管理员

**使命**：收集高质量参考文献，建立文献库。

**输入**：`{workspace}/proposal/brief.md` + 前两个Agent的调研报告（如有）

**任务**：
1. 搜索该领域权威期刊、经典著作、最新进展
2. 按类别整理：理论基础类、方法类、应用类、政策类
3. 确保中英文文献比例合理
4. 优先选择近5年文献，经典文献不限年份
5. 收集≥30条高质量文献

**输出**：保存至 `{workspace}/proposal/research/references.md`

**输出格式**：
```markdown
# 参考文献清单

## 理论基础
1. [作者]. [标题]. [期刊/出版社], [年份]. [URL/DOI]

## 方法技术
...

## 应用实践
...

## 政策背景
...
```

---

### 阶段2：方案设计（串行+并行写作Agent）

**目标**：基于调研成果，撰写研究内容、重点、难点、方法。

**输入**：阶段1全部调研报告

**依赖分析**：
```
研究内容 ← 文献卡点 + 痛点
研究重点 ← 研究内容
研究难点 ← 研究重点
研究方法 ← 研究难点 + 文献方法
```

**Round 1（并行）**：

#### Agent 4: 方案设计师 — 研究内容

**类型**：`subagent_type="coder"`

**输入**：
- `{workspace}/proposal/brief.md`
- `{workspace}/proposal/research/pain_analysis.md`
- `{workspace}/proposal/research/literature_review.md`

**参考**：`{skill_path}/references.md` 中"研究内容/目标"分类下的文献 [2], [9], [10], [11], [17], [18]，学习"问题树"方法、模块化设计、SMART目标设定等方法论。

**任务**：
1. 基于卡点和痛点，设计具体的研究内容（3-5个子内容）
2. 每个子内容说明：做什么、为什么做、预期产出
3. 研究内容之间要有逻辑递进关系
4. 确保每个研究内容直接对应一个卡点的解决方案

**输出**：`{workspace}/proposal/draft/sec03_content.md`

#### Agent 5: 方法专家 — 研究方法

**类型**：`subagent_type="coder"`

**输入**：
- `{workspace}/proposal/brief.md`
- `{workspace}/proposal/research/literature_review.md`

**参考**：`{skill_path}/references.md` 中"研究方法/技术路线"分类下的文献 [2], [9], [10], [14], [16], [20]，学习方法选择理由阐述、技术路线可视化、方法透明可复现等方法论。

**任务**：
1. 基于文献中的方法脉络，选择最适合解决本课题卡点的方法
2. 说明方法选择的理由（为什么这个方法适合解决这个卡点）
3. 描述方法的具体实施步骤
4. 如有方法创新，说明创新点

**输出**：`{workspace}/proposal/draft/sec06_methods.md`

**Round 2（串行，依赖Round 1）**：

#### Agent 6: 重点提炼师 — 研究重点

**类型**：`subagent_type="coder"`

**输入**：
- `{workspace}/proposal/draft/sec03_content.md`（研究内容）
- `{workspace}/proposal/research/literature_review.md`

**参考**：`{skill_path}/references.md` 中"研究重点/难点"分类下的文献 [8], [10], [14], [20]，学习如何从内容中提炼核心、说明关键性、标注主次关系等方法论。

**任务**：
1. 从研究内容中提炼2-3个最核心的部分
2. 说明为什么这些是重点（对解决卡点的关键作用）
3. 重点之间要有主次关系

**输出**：`{workspace}/proposal/draft/sec04_keypoints.md`

#### Agent 7: 难点识别师 — 研究难点

**类型**：`subagent_type="coder"`

**输入**：
- `{workspace}/proposal/draft/sec04_keypoints.md`（研究重点）
- `{workspace}/proposal/draft/sec06_methods.md`（研究方法）
- `{workspace}/proposal/research/literature_review.md`

**参考**：`{skill_path}/references.md` 中"研究重点/难点"分类下的文献 [8], [10], [14], [20]，学习如何识别挑战环节、分析成因、提出应对策略、与方法形成呼应等方法论。

**任务**：
1. 识别研究重点中最具挑战性的环节（1-2个难点）
2. 分析难点的成因（技术、数据、理论、资源等）
3. 提出应对策略（如何克服这些难点）
4. 难点要与研究方法形成呼应

**输出**：`{workspace}/proposal/draft/sec05_difficulties.md`

---

### 阶段3：论证与包装（并行写作Agent）

**目标**：撰写可行性、创新之处、研究基础、参考文献。

**输入**：阶段2全部草案

**Round 1（并行，均依赖阶段2输出）**：

#### Agent 8: 可行性分析师 — 可行性

**类型**：`subagent_type="coder"`

**输入**：
- `{workspace}/proposal/draft/sec03_content.md`
- `{workspace}/proposal/draft/sec06_methods.md`
- `{workspace}/proposal/brief.md`（团队背景）

**参考**：`{skill_path}/references.md` 中"可行性分析"分类下的文献 [2], [11], [17], [19], [20]，学习团队+资源+技术+时间四维度论证、预算与目标对齐、NIH评审Environment维度等方法论。

**任务**：
1. 从团队条件论证（人员、经验、设备）
2. 从资源条件论证（数据、经费、合作）
3. 从技术路线论证（方法成熟度和可操作性）
4. 从时间规划论证（研究周期合理）

**输出**：`{workspace}/proposal/draft/sec07_feasibility.md`

#### Agent 9: 创新提炼师 — 创新之处

**类型**：`subagent_type="coder"`

**输入**：
- `{workspace}/proposal/draft/sec03_content.md`
- `{workspace}/proposal/draft/sec06_methods.md`
- `{workspace}/proposal/research/literature_review.md`

**参考**：`{skill_path}/references.md` 中"创新之处"分类下的文献 [7], [8], [10], [11], [20]，学习从研究角度/方法/观点/材料挖掘创新、基于文献比较、避免"填补空白"空泛表述、NIH评审Innovation维度等方法论。

**任务**：
1. 对比现有研究（文献中的卡点），明确本研究的推进点
2. 提炼2-3个创新点（理论创新、方法创新、应用创新）
3. 每个创新点说明：新在哪里、为什么重要、如何验证
4. 创新点要与研究内容和方法形成闭环

**输出**：`{workspace}/proposal/draft/sec08_innovation.md`

#### Agent 10: 基础梳理师 — 研究基础

**类型**：`subagent_type="coder"`

**输入**：
- `{workspace}/proposal/brief.md`
- `{workspace}/proposal/draft/sec03_content.md`

**参考**：`{skill_path}/references.md` 中"研究基础"分类下的文献 [1], [11], [14], [16], [19]，学习成果关联本课题、证明解决能力、展示前期积累、NIH评审Investigators维度等方法论。

**任务**：
1. 梳理研究者已有的相关成果（论文、项目、专利）
2. 说明这些成果与本课题的关联
3. 证明研究者具备解决类似问题的能力
4. 如有团队，说明团队分工和互补性

**输出**：`{workspace}/proposal/draft/sec09_foundation.md`

#### Agent 11: 选题依据撰写师 — 选题依据

**类型**：`subagent_type="coder"`

**输入**：
- `{workspace}/proposal/research/pain_analysis.md`
- `{workspace}/proposal/research/literature_review.md`

**参考**：`{skill_path}/references.md` 中核心方法论"贩卖焦虑策略"及文献 [1], [8], [9], [15]，学习数据开场、政策关联、学术需求、价值升华、避免空泛等方法论。

**任务**：
1. 以"贩卖焦虑"策略撰写：从社会痛点切入，层层递进
2. 结构：社会现实痛点 → 学术/实践需求 → 研究价值
3. 用数据和案例支撑，避免空泛
4. 语言要有紧迫感，但保持学术严谨

**输出**：`{workspace}/proposal/draft/sec01_rationale.md`

#### Agent 12: 研究现状撰写师 — 研究现状

**类型**：`subagent_type="coder"`

**输入**：
- `{workspace}/proposal/research/literature_review.md`
- `{workspace}/proposal/draft/sec03_content.md`

**参考**：`{skill_path}/references.md` 中核心方法论"找卡点策略"及文献 [1], [6], [9], [10], [14]，学习脉络组织、批判分析、指出不足、自然衔接、引用质量等方法论。

**任务**：
1. 以"找卡点"策略撰写：梳理文献 → 指出进展 → 暴露瓶颈
2. 按脉络组织，不要简单罗列文献
3. 每个脉络最后明确指出"现有研究尚未解决..."
4. 卡点要与本课题的研究内容形成自然衔接

**输出**：`{workspace}/proposal/draft/sec02_status.md`

#### Agent 13: 参考文献格式化师

**类型**：`subagent_type="coder"`

**输入**：
- `{workspace}/proposal/research/references.md`
- 已撰写的所有草案（提取实际引用的文献）

**任务**：
1. 按资助机构要求的格式整理参考文献
2. 确保正文中引用的文献都在列表中
3. 按引用顺序或字母顺序排列
4. 检查格式一致性

**输出**：`{workspace}/proposal/draft/sec10_references.md`

---

### 阶段4：整合与评审

**目标**：合并所有模块，检查逻辑一致性，确保学术规范。

#### 步骤1：逻辑一致性检查（plan Agent）

**Agent**：逻辑检查员（`subagent_type="plan"`）

**输入**：所有 `sec*.md` 文件

**参考**：`{skill_path}/references.md` 中核心方法论"逻辑闭环原则"及"评审人视角原则"，学习如何从评审人角度审视申报书逻辑链完整性。

**检查清单**：
1. **选题依据 → 研究现状**：痛点是否引出了卡点？
2. **研究现状 → 研究内容**：卡点是否被研究内容覆盖？
3. **研究内容 → 研究重点**：重点是否是内容的核心？
4. **研究重点 → 研究难点**：难点是否在重点之中？
5. **研究难点 → 研究方法**：方法是否能解决难点？
6. **研究方法 → 可行性**：方法是否在现有条件下可行？
7. **创新之处 → 研究现状**：创新是否相对于现有研究？
8. **研究基础 → 研究内容**：基础是否支撑内容？
9. **参考文献 → 全文**：引用是否准确、格式是否规范？

**输出**：`{workspace}/proposal/review/logic_check.md`

**格式**：
```markdown
# 逻辑一致性检查报告

## 检查项1：选题依据 → 研究现状
- 状态：[通过/警告/失败]
- 说明：
- 建议：

## 检查项2：...

## 总体评估
- 逻辑链完整性：
- 需要修改的模块：
```

#### 步骤2：质量评审（plan Agent）

**Agent**：质量评审员（`subagent_type="plan"`）

**输入**：所有 `sec*.md` + `logic_check.md`

**评审维度**：
1. **学术规范**：引用格式、术语使用、论证逻辑
2. **语言表达**：学术性、简洁性、无冗余
3. **说服力**：痛点是否打动人、方案是否可信、创新是否突出
4. **完整性**：是否覆盖所有要求模块

**输出**：`{workspace}/proposal/review/quality_review.md`

#### 步骤3：修改迭代（条件触发）

如果逻辑检查或质量评审发现问题：
1. Orchestrator根据评审报告，指派对应Agent修改
2. 修改后重新评审，直到通过

---

### 阶段5：组装与输出

**目标**：合并所有模块为最终文档，转换为指定格式。

#### 步骤1：合并

Orchestrator或Coder Agent按顺序合并所有 `sec*.md`：

```
sec01_rationale.md → sec02_status.md → sec03_content.md → sec04_keypoints.md
  → sec05_difficulties.md → sec06_methods.md → sec07_feasibility.md
    → sec08_innovation.md → sec09_foundation.md → sec10_references.md
```

保存为：`{workspace}/proposal/final/proposal.agent.final.md`

**合并规则**：
1. 保留各模块的标题层级
2. 统一脚注格式，去重
3. 检查交叉引用
4. 确保UTF-8编码

#### 步骤2：格式转换

使用 `docx` skill 将 `.md` 转换为 `.docx`：

```
{workspace}/proposal/final/proposal.agent.final.md
  → {workspace}/proposal/final/proposal.docx
```

---

## Agent角色总览

| 编号 | Agent角色 | 类型 | 负责模块 | 依赖阶段 |
|------|-----------|------|----------|----------|
| 1 | 痛点分析师 | explore | 选题依据素材 | 阶段0 |
| 2 | 文献调研员 | explore | 研究现状素材 | 阶段0 |
| 3 | 参考文献管理员 | explore | 参考文献素材 | 阶段0 |
| 4 | 方案设计师 | coder | 研究内容 | 阶段1 |
| 5 | 方法专家 | coder | 研究方法 | 阶段1 |
| 6 | 重点提炼师 | coder | 研究重点 | 阶段2-R1 |
| 7 | 难点识别师 | coder | 研究难点 | 阶段2-R2 |
| 8 | 可行性分析师 | coder | 可行性 | 阶段2 |
| 9 | 创新提炼师 | coder | 创新之处 | 阶段2 |
| 10 | 基础梳理师 | coder | 研究基础 | 阶段2 |
| 11 | 选题依据撰写师 | coder | 选题依据 | 阶段2 |
| 12 | 研究现状撰写师 | coder | 研究现状 | 阶段2 |
| 13 | 参考文献格式化师 | coder | 参考文献 | 阶段2 |
| 14 | 逻辑检查员 | plan | 逻辑一致性 | 阶段3 |
| 15 | 质量评审员 | plan | 质量评审 | 阶段3 |

---

## 并发策略

运行时并发限制通常为~4个Agent。按以下批次调度：

**阶段1（调研）**：
- Batch 1：痛点分析师 + 文献调研员 + 参考文献管理员（3个并行）

**阶段2-R1（方案初稿）**：
- Batch 1：方案设计师 + 方法专家（2个并行）

**阶段2-R2（方案深化）**：
- Batch 1：重点提炼师（依赖研究内容）
- Batch 2：难点识别师（依赖研究重点）

**阶段3（论证包装）**：
- Batch 1：可行性分析师 + 创新提炼师 + 基础梳理师 + 选题依据撰写师 + 研究现状撰写师（5个并行，分两轮）
- Batch 2：参考文献格式化师（依赖前面所有模块）

**阶段4（评审）**：
- Batch 1：逻辑检查员
- Batch 2：质量评审员（依赖逻辑检查）

---

## 写作策略速查

| 模块 | 核心策略 | 写作要点 |
|------|----------|----------|
| 选题依据 | 贩卖焦虑 | 痛点→需求→价值，数据支撑，层层递进 |
| 研究现状 | 找卡点 | 脉络梳理→指出进展→暴露瓶颈，不要罗列 |
| 研究内容 | 解决方案 | 每个内容对应一个卡点，逻辑递进 |
| 研究重点 | 关键内容 | 从内容中提炼核心，说明关键性 |
| 研究难点 | 重点中的难点 | 识别挑战，分析成因，提出应对 |
| 研究方法 | 解决卡点 | 方法→卡点匹配，说明选择理由 |
| 可行性 | 条件支撑 | 团队+资源+技术+时间，四维度论证 |
| 创新之处 | 相比推进 | 对比现有研究，明确新贡献 |
| 研究基础 | 我的经验 | 成果关联，能力证明 |
| 参考文献 | 与谁为伍 | 权威+前沿+相关，体现水准 |

---

## 核心原则

1. **调研与写作分离** — 探索Agent只做调研，Coder Agent只做写作
2. **Markdown先行** — 所有中间产物为 `.md`，最终转 `.docx`
3. **依赖驱动调度** — 严格按逻辑依赖分Round，不盲目并行
4. **文件传递上下文** — Agent间通过文件传递信息，不依赖隐式上下文
5. **评审是硬门槛** — 逻辑检查不通过必须修改，不能跳过
6. **引用完整性** — 所有引用必须有对应文献，格式统一
7. **语言一致性** — 全部使用中文撰写
8. **用户确认节点** — 阶段0（Brief）和阶段1（调研）完成后，建议用户确认后再进入写作阶段
9. **方法论参考文献支撑** — 各Agent撰写对应模块时，应参考 `{skill_path}/references.md` 中的成熟经验和最佳实践，确保撰写策略符合学术规范和评审期待
