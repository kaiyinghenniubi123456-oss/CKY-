---
name: teaching-plan-custom
description: |
  教案填写通用工作流（可替换模板）。当用户提供学校教案模板时触发。
  自动扫描模板结构→提取字段位置→按教材解读报告和资源检索报告填写→生成教案docx。
  支持任何教案模板（不限学校），只需用户提供一个模板文件即可。
  内容必须严格来源于上游 textbook-interpretation 和 textbook-resource-workflow 的输出，禁止凭空添加教学内容。
  触发词："填教案""教案模板""根据教材写教案""备课""教案填写"。
  流程位置：教学全流程 Step 3（上游=textbook-interpretation + textbook-resource-workflow，下游=无固定下游）。
agent_created: true
---

# 教案填写 · 通用模板版 V2

## 适用场景

- 任何学校、任何学科的教案填写
- 用户提供自己的学校教案模板（.docx 文件）
- 根据教材解读内容自动生成教案
- **自动扫描模板结构**，适配任意表格布局

## 联动协议（核心原则）

### 上游衔接（必须遵守）

1. **内容来源锁定**：教案的所有教学内容（重点、难点、目标、案例、资源）必须来源于 `textbook-interpretation` 解读报告和 `textbook-resource-workflow` 资源检索报告
2. **编号引用**：教案中引用重点必须标注"重点N"，引用难点标注"难点N"，引用资源标注"资源#N"
3. **禁止凭空添加**：不得引入解读报告中未涉及的新知识点，不得使用资源检索报告中未搜集的资源
4. **一例到底贯穿**：全程用同一案例的不同侧面串讲（导入设疑→新授分模块→练习辨析），案例选取与解读报告突破方式一致

### 下游衔接（可选）

教案完成后，可继续走 `teaching-ppt-swiss`（PPT制作），PPT 每页内容与教案教学过程环节一一对应。

## 核心工作流（5步，严格按序，禁止跳步）

### 第 1 步：确认上游报告已就绪

检查以下文件是否存在于当前项目目录：
1. **教材解读报告**（`XXX_任务N_教材解读报告.md`）— 如不存在，告知用户先用 `textbook-interpretation` 解读
2. **资源检索报告**（`XXX_任务N_资源检索报告.md`）— 如不存在，告知用户先用 `textbook-resource-workflow` 检索
3. **学校教案模板**（.docx）— 用户必须提供

读取两份报告，提取：
- 重点编号列表（重点1-5）及其内容
- 难点编号列表（难点1-12）及其内容
- 资源编号列表（#1-#15）及其名称和链接
- 一句话结论中的主线案例

### 第 2 步：扫描模板结构（⚡ 关键步骤）

模板探查脚本（首次接入新模板必跑）：

```python
from docx import Document
from docx.oxml.ns import qn

doc = Document('<模板路径>')

# 1. 非表格段落
for pi, para in enumerate(doc.paragraphs):
    if para.text.strip():
        print(f'段落{pi+1}: [{para.text.strip()[:80]}]')

# 2. 表格结构（含合并单元格分析）
for ti, tbl in enumerate(doc.tables):
    print(f"=== 表格 {ti+1} ({len(tbl.rows)}行 × {len(tbl.columns)}列) ===")
    for ri, row in enumerate(tbl.rows):
        seen = set()
        for ci, c in enumerate(row.cells):
            if id(c._tc) in seen: continue
            seen.add(id(c._tc))
            # 检查合并信息
            tcPr = c._tc.find(qn('w:tcPr'))
            gridSpan = tcPr.find(qn('w:gridSpan')) if tcPr is not None else None
            vMerge = tcPr.find(qn('w:vMerge')) if tcPr is not None else None
            mergeInfo = ''
            if gridSpan is not None: mergeInfo += f' span={gridSpan.get(qn("w:val"))}'
            if vMerge is not None: mergeInfo += f' vMerge={vMerge.get(qn("w:val"), "continue")}'
            cell_text = c.text.strip()[:60].replace('\n', ' | ')
            print(f'  行{ri+1} C{ci}{mergeInfo}: [{cell_text}]')
```

扫描后，确认每个字段对应的（表格索引, 行号, 列号）。**特别注意合并单元格的 span 和 vMerge 信息**。

### 第 3 步：向用户问缺失信息（**不允许瞎填**）

下列字段如果不主动问，会填出错的：

| 字段 | 默认值 | 询问优先级 |
|------|--------|----------|
| 课题 | 教材任务标题 | 通常不用问 |
| 课时 | 2 | 教材内容 > 2 课时容量时**必问** |
| 授课时间 | 不填 / 留空 | **必问**（学校可能要求具体日期） |
| 课型 | 新授课 | 几乎都是新授课，可不问 |
| 教材 | 教材全名+主编+出版社+版次 | 可不问（已读教材） |
| 教学方法 | 案例教学法 + 任务驱动法 | **必问** |

⚠️ **绝对禁止**：把"授课时间""教学方法"这些没问就填了。

### 第 4 步：按模板填写（Python脚本）

#### Python 环境路径

```bash
# 使用 venv Python（已安装 python-docx）
/Users/a123/.workbuddy/binaries/python/envs/default/bin/python3
```

#### 合并单元格处理（通用方案）

```python
# 写入前先扫每行唯一 tc 的列位
seen = set()
for ci, c in enumerate(row.cells):
    if id(c._tc) in seen: continue
    seen.add(id(c._tc))
    # ci 才是正确的列号
```

#### 字号与字体（强约束）

- **正文统一 12pt（小四号）**
- 中文字体：宋体（`eastAsia` 显式声明）
- 英文字体：Times New Roman（`ascii` / `hAnsi` / `cs`）
- 中文标点必须全角：（，）。：；「」——

```python
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Pt

def set_run_font(run, cn='宋体', en='Times New Roman', pt=12):
    run.font.name = en
    run.font.size = Pt(pt)
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.insert(0, rFonts)
    rFonts.set(qn('w:ascii'), en)
    rFonts.set(qn('w:hAnsi'), en)
    rFonts.set(qn('w:eastAsia'), cn)
    rFonts.set(qn('w:cs'), en)
```

#### 教学过程设计原则（联动版）

**6 环节结构**：

| 环节 | 时长 | 核心动作 | 联动编号 |
|------|------|----------|---------|
| 课前任务 | — | 2-3 个导学问题做认知铺垫 | 难点N |
| 导入 | 5-10min | 案例设疑（一例到底主线案例），建立"今天要学什么"的期待 | 重点1→难点核心 |
| 新授 | 25-30min | 分模块，每模块"讲授+学生活动+设计意图"，标注重点N+难点N | 重点1→5 |
| 练习与展示 | 5min | 真实场景辨析 / 案例演练 / 抢答，回到主线案例 | 难点N |
| 小结 | 2min | 思维导图 / 知识树 / 知识口诀 | 全重点回顾 |
| 作业 | — | 必做+选做+拓展 三段式 | 资源#N引用 |

**每个教学过程环节必须标注**：对应重点编号、难点编号、使用资源编号。

#### "一例到底"教学设计（推荐，联动核心）

导入、新授中段、练习环节**全程用同一案例串讲**，避免案例碎片化：
- **案例选取**：从解读报告的突破方式中选取最贯穿的案例（如锅圈食汇）
- 导入用案例设疑 → 新授分模块继续用同一案例的不同侧面 → 练习再回到该案例做辨析
- 思政融入：选取与案例相关的社会热点或经典金句
- 练习拓展：可引入其他真实品牌/案例做对比辨析
- **每环节标注**："本环节继续用[主线案例]的[XX侧面]突破[难点N]"

#### 数字资源填写（联动版）

教案"数字资源"栏必须列出资源检索报告中的资源编号：

```
资源#1：锅圈食汇品牌故事（搜狐网，认知阶段）
资源#6：锅圈食汇综艺营销（网易，案例阶段）
资源#11：3·15晚会虚假宣传（B站，案例阶段）
资源#14：4Ps方案设计任务卡（自编模板，实训阶段）
```

### 第 5 步：保存与交付

- 输出文件名：`任务N_课题名_教案.docx`
- 保存到用户项目目录（不保存到 Desktop，沙箱可能限制写入）
- 用 `present_files` 交付
- 更新当日 memory

## 关键踩坑

1. **合并单元格**：`table.cell(r, c)` 在合并区返回同一对象；必须先扫唯一 tc，**特别注意 gridSpan 和 vMerge**
2. **模板默认字号**：必须**显式声明**到每个 run，模板默认值不可靠
3. **清空单元格**：删 `_element` 比 `text = ''` 干净（先清除所有子段落和 run）
4. **中文字体回退**：不显式声明 `eastAsia`，Word 会用西文字体渲染中文
5. **瞎填字段**：授课时间、教学方法必须问
6. **沙箱限制**：Desktop 目录可能被沙箱限制写入，优先保存到项目目录
7. **Python 路径**：必须用 venv Python（`/Users/a123/.workbuddy/binaries/python/envs/default/bin/python3`），不是系统 Python

## 学科定制说明

本 Skill **不限定学科**。教学过程环节设计可根据学科调整：

| 学科类型 | 练习环节示例 |
|---|---|
| 市场营销 | 真实品牌辨析 / 案例演练 / 抢答 |
| 思政/政治 | 时政热点讨论 / 案例分析 |
| 数学/物理 | 典型例题演算 / 分组解题 |
| 语文 | 文本细读 / 写作片段练习 |
| 计算机 | 编程实战 / 代码 Review |

**核心结构不变（6 环节 + 联动编号），但具体内容随学科调整。** 模板扫描时自动识别字段名称，不硬编码"教学方法""教学设计意图"等具体文字。
