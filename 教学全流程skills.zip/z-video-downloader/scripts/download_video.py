#!/usr/bin/env python3
"""Download videos from direct URLs and yt-dlp supported platforms.

Adapted from tjxj/z-skills for 陈开颖 (CC) environment.
Uses managed Python 3.13 and finds yt-dlp dynamically.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
import time
import warnings
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urljoin, urlparse

warnings.filterwarnings(
    "ignore",
    message=r"urllib3 .* doesn't match a supported version!",
)

import requests

# Output root — use desktop for portability
DEFAULT_OUT_ROOT = Path.home() / "Desktop" / "Video-Downloads"

# Find yt-dlp via multiple candidates
MANAGED_PYTHON_BIN = Path(
    "/Users/a123/.workbuddy/binaries/python/versions/3.13.12/bin"
)
YTDLP_CANDIDATES = [
    MANAGED_PYTHON_BIN / "yt-dlp",  # if installed as script
    Path(shutil.which("yt-dlp") or ""),
    MANAGED_PYTHON_BIN / "pip-scripts" / "yt-dlp",
]

DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/125.0 Safari/537.36"
)

VIDEO_EXTENSIONS = {".mp4", ".webm", ".mov", ".m4v", ".mkv", ".flv", ".ogv"}
STREAM_EXTENSIONS = {".m3u8", ".mpd"}

PLATFORM_HOST_HINTS = {
    "youtube.com": "YouTube",
    "youtu.be": "YouTube",
    "bilibili.com": "Bilibili",
    "b23.tv": "Bilibili",
    "bilivideo.cn": "Bilibili",
    "vimeo.com": "Vimeo",
    "x.com": "X",
    "twitter.com": "Twitter",
    "tiktok.com": "TikTok",
    "douyin.com": "Douyin",
    "instagram.com": "Instagram",
    "facebook.com": "Facebook",
    "baidu.com": "百度",
    "acg.tv": "AcFun",
}

INVIDIOUS_INSTANCES = (
    "https://inv.thepixora.com",
)
INVIDIOUS_FALLBACK_ITAG = "18"  # 360p progressive MP4 with audio.


def slugify(text: str, fallback: str = "video-download", max_len: int = 60) -> str:
    value = re.sub(r"[^\w.-]+", "-", text, flags=re.U).strip("-._")
    value = re.sub(r"-{2,}", "-", value)
    if not value:
        value = fallback
    return value[:max_len].strip("-._") or fallback


def safe_filename(text: str, fallback: str = "video") -> str:
    value = unquote(text or "").strip()
    value = re.sub(r"[\\/:*?\"<>|\x00-\x1f]+", "_", value)
    value = re.sub(r"\s+", " ", value).strip(" .")
    return value or fallback


def make_run_dir(out_root: Path, title: str) -> Path:
    date = dt.date.today().isoformat()
    name = slugify(title or "video-download")
    candidate = out_root / f"{date}-{name}"
    if not candidate.exists():
        candidate.mkdir(parents=True, exist_ok=True)
        return candidate
    for index in range(2, 1000):
        with_suffix = out_root / f"{date}-{name}-{index:02d}"
        if not with_suffix.exists():
            with_suffix.mkdir(parents=True, exist_ok=True)
            return with_suffix
    raise RuntimeError(f"Cannot create unique output directory under {out_root}")


def find_ytdlp() -> Path | None:
    """Find yt-dlp executable."""
    # Try direct binary
    for candidate in YTDLP_CANDIDATES:
        if candidate and candidate.exists() and os.access(candidate, os.X_OK):
            return candidate
    # Try via python -m
    result = subprocess.run(
        [str(MANAGED_PYTHON_BIN / "python3.13"), "-m", "yt_dlp", "--version"],
        capture_output=True, text=True, timeout=10,
    )
    if result.returncode == 0:
        # Return a wrapper approach
        return "python-module"
    return None


def find_ffmpeg() -> str:
    """Find ffmpeg executable path for yt-dlp --ffmpeg-location."""
    # 1. imageio-ffmpeg bundled binary (most reliable in this environment)
    try:
        import imageio_ffmpeg
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        if Path(exe).exists():
            return str(Path(exe).parent)
    except Exception:
        pass
    # 2. User local bin symlink
    local_bin = Path("/Users/a123/local/bin/ffmpeg")
    if local_bin.exists():
        return "/Users/a123/local/bin"
    # 3. System path
    which = shutil.which("ffmpeg")
    if which:
        return str(Path(which).parent)
    return ""


def classify_url(url: str) -> str:
    parsed = urlparse(url)
    suffix = Path(parsed.path).suffix.lower()
    if suffix in VIDEO_EXTENSIONS:
        return "direct"
    if suffix in STREAM_EXTENSIONS:
        return "stream"
    return "platform"


def platform_name(url: str) -> str:
    host = urlparse(url).netloc.lower()
    for hint, name in PLATFORM_HOST_HINTS.items():
        if host == hint or host.endswith("." + hint):
            return name
    if classify_url(url) == "direct":
        return "Direct"
    if classify_url(url) == "stream":
        return "Stream"
    return "yt-dlp"


def youtube_video_id(url: str) -> str:
    parsed = urlparse(url)
    host = parsed.netloc.lower()
    path = parsed.path.strip("/")
    candidate = ""
    if host == "youtu.be" or host.endswith(".youtu.be"):
        candidate = path.split("/", 1)[0]
    elif host == "youtube.com" or host.endswith(".youtube.com"):
        if parsed.path == "/watch":
            candidate = (parse_qs(parsed.query).get("v") or [""])[0]
        elif path.startswith(("shorts/", "embed/", "live/")):
            candidate = path.split("/", 1)[1].split("/", 1)[0]
    if re.fullmatch(r"[\w-]{11}", candidate or ""):
        return candidate
    return ""


def is_youtube_url(url: str) -> bool:
    return bool(youtube_video_id(url))


def download_direct_video(
    session: requests.Session,
    url: str,
    out_dir: Path,
    *,
    max_video_mb: float,
    referer: str = "",
    timeout: int = 30,
) -> dict[str, Any]:
    record = base_record(url, "direct")
    try:
        headers = {"User-Agent": DEFAULT_USER_AGENT}
        if referer:
            headers["Referer"] = referer
        response = session.get(url, timeout=timeout, stream=True, headers=headers)
        response.raise_for_status()
        content_type = response.headers.get("Content-Type", "").lower()
        if "text/html" in content_type or "application/json" in content_type:
            record["note"] = f"unexpected-content-type:{content_type.split(';')[0]}"
            return record

        limit = int(max_video_mb * 1024 * 1024)
        length = response.headers.get("Content-Length")
        if length:
            try:
                if int(length) > limit:
                    record["note"] = f"video-larger-than-{max_video_mb:g}MB"
                    return record
            except ValueError:
                pass

        parsed = urlparse(url)
        ext = Path(parsed.path).suffix.lower()
        if ext not in VIDEO_EXTENSIONS:
            ext = ".mp4"
        header_name = filename_from_headers(response.headers)
        fallback_stem = safe_filename(Path(parsed.path).stem or "video")
        filename = header_name or f"{fallback_stem}{ext}"
        if Path(filename).suffix.lower() not in VIDEO_EXTENSIONS:
            filename = f"{Path(filename).stem}{ext}"
        target = unique_path(out_dir / filename)

        size = 0
        with open(target, "wb") as handle:
            for chunk in response.iter_content(1024 * 256):
                if not chunk:
                    continue
                size += len(chunk)
                if size > limit:
                    handle.close()
                    target.unlink(missing_ok=True)
                    record["note"] = f"video-larger-than-{max_video_mb:g}MB"
                    return record
                handle.write(chunk)

        record["status"] = "ok"
        record["files"] = [str(target)]
        record["bytes"] = size
        return record
    except Exception as exc:
        record["note"] = str(exc)[:300]
        return record


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    for index in range(2, 1000):
        candidate = path.with_name(f"{stem}-{index:02d}{suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"Cannot create unique filename for {path}")


def filename_from_headers(headers) -> str:
    disposition = headers.get("Content-Disposition", "")
    match = re.search(r"filename\*=UTF-8''([^;]+)", disposition, re.I)
    if match:
        return safe_filename(match.group(1))
    match = re.search(r'filename="?([^";]+)"?', disposition, re.I)
    if match:
        return safe_filename(match.group(1))
    return ""


def format_selector(quality: str) -> str:
    if quality == "best":
        return "bv*+ba/b"
    try:
        height = int(quality)
    except ValueError as exc:
        raise ValueError("--quality must be an integer height like 1080 or 'best'") from exc
    return f"bv*[height<={height}]+ba/b[height<={height}]/b"


def build_ytdlp_cmd(
    url: str,
    out_dir: Path,
    *,
    ytdlp_executable: str,
    quality: str,
    max_video_mb: float,
    cookies_file: str = "",
    browser_cookies: str = "",
    playlist: bool = False,
    write_info_json: bool = True,
    trim_filenames: int = 150,
) -> list[str]:
    template = str(out_dir / "%(title).150B [%(id)s].%(ext)s")
    cmd = [
        ytdlp_executable,
        "--no-progress",
        "--print",
        "after_move:filepath",
        "--merge-output-format",
        "mp4",
        "--embed-metadata",
        "--trim-filenames",
        str(trim_filenames),
        "--max-filesize",
        f"{int(max_video_mb)}M",
        "-f",
        format_selector(quality),
        "-o",
        template,
        url,
    ]
    if write_info_json:
        cmd.insert(1, "--write-info-json")
    if playlist:
        cmd.insert(1, "--yes-playlist")
    else:
        cmd.insert(1, "--no-playlist")
    if cookies_file:
        cmd[1:1] = ["--cookies", str(Path(cookies_file).expanduser())]
    elif browser_cookies:
        cmd[1:1] = ["--cookies-from-browser", browser_cookies]
    return cmd


def likely_cookie_fix(note: str) -> bool:
    lowered = note.lower()
    markers = [
        "sign in", "login", "cookies", "captcha", "bot",
        "precondition", "http error 412", "http error 403",
        "forbidden", "confirm",
    ]
    return any(marker in lowered for marker in markers)


def size_text(size) -> str:
    if size is None:
        return ""
    units = ["B", "KB", "MB", "GB"]
    value = float(size)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(value)} {unit}"
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} B"


def base_record(url: str, kind: str) -> dict[str, Any]:
    return {
        "url": url,
        "kind": kind,
        "platform": platform_name(url),
        "status": "failed",
        "files": [],
        "bytes": 0,
        "note": "",
    }


def get_ytdlp_command(ytdlp_path) -> str:
    """Get the correct yt-dlp command for this environment."""
    if ytdlp_path == "python-module":
        return f'"{MANAGED_PYTHON_BIN / "python3.13"}" -m yt_dlp'
    return f'"{ytdlp_path}"'


def download_with_ytdlp(
    url: str,
    out_dir: Path,
    *,
    ytdlp_path: Path | str,
    quality: str,
    max_video_mb: float,
    cookies_file: str = "",
    browser_cookies: str = "",
    playlist: bool = False,
    timeout: int = 3600,
) -> dict[str, Any]:
    kind = "stream" if classify_url(url) == "stream" else "platform"
    record = base_record(url, kind)

    # Build yt-dlp command
    if ytdlp_path == "python-module":
        ytdlp_cmd = [
            str(MANAGED_PYTHON_BIN / "python3.13"),
            "-m", "yt_dlp",
        ]
    else:
        ytdlp_cmd = [str(ytdlp_path)]

    ytdlp_cmd.extend([
        "--no-progress",
        "--print", "after_move:filepath",
        "--merge-output-format", "mp4",
        "--embed-metadata",
        "--trim-filenames", str(150),
        "--max-filesize", f"{int(max_video_mb)}M",
        "-f", format_selector(quality),
        "-o", str(out_dir / "%(title).150B [%(id)s].%(ext)s"),
    ])

    # Add ffmpeg location so yt-dlp can merge audio+video
    ffmpeg_dir = find_ffmpeg()
    if ffmpeg_dir:
        ytdlp_cmd.extend(["--ffmpeg-location", ffmpeg_dir])

    ytdlp_cmd.insert(1, "--write-info-json")

    if playlist:
        ytdlp_cmd.insert(1, "--yes-playlist")
    else:
        ytdlp_cmd.insert(1, "--no-playlist")

    if cookies_file:
        ytdlp_cmd[1:1] = ["--cookies", str(Path(cookies_file).expanduser())]
    elif browser_cookies:
        ytdlp_cmd[1:1] = ["--cookies-from-browser", browser_cookies]

    ytdlp_cmd.append(url)

    try:
        env = os.environ.copy()
        env["PYTHONPATH"] = str(
            MANAGED_PYTHON_BIN.parent / "lib" / "python3.13" / "site-packages"
        )
        # Ensure PATH includes ffmpeg location
        ffmpeg_dir = find_ffmpeg()
        if ffmpeg_dir:
            env["PATH"] = ffmpeg_dir + os.pathsep + env.get("PATH", "")
        print(f"[DEBUG] cwd={str(out_dir)}", file=sys.stderr)
        print(f"[DEBUG] out_dir exists: {out_dir.exists()}", file=sys.stderr)
        print(f"[DEBUG] out_dir writable: {os.access(out_dir, os.W_OK)}", file=sys.stderr)
        proc = subprocess.run(
            ytdlp_cmd,
            capture_output=True, text=True, timeout=timeout, env=env,
            cwd=str(out_dir),
        )
        print(f"[DEBUG] returncode={proc.returncode}", file=sys.stderr)
        print(f"[DEBUG] stderr={(proc.stderr or b'')[:500]}", file=sys.stderr)
        print(f"[DEBUG] stdout={(proc.stdout or b'')[:300]}", file=sys.stderr)

        video_exts = {".mp4", ".webm", ".mov", ".m4v", ".mkv", ".flv", ".ogv"}
        printed_files = []
        for line in (proc.stdout or "").splitlines():
            p = Path(line.strip())
            if p.exists() and p.suffix.lower() in video_exts:
                printed_files.append(str(p))
        print(f"[DEBUG] printed_files={printed_files}", file=sys.stderr)

        # After: find new video files in output dir
        try:
            after_files = [str(p) for p in out_dir.iterdir()]
            print(f"[DEBUG] after_files={after_files}", file=sys.stderr)
        except PermissionError:
            after_files = [str(out_dir / f) for f in os.listdir(out_dir)]
            print(f"[DEBUG] after_files(os.listdir)={after_files}", file=sys.stderr)
        after_paths = [
            f for f in after_files
            if Path(f).suffix.lower() in video_exts
        ]
        # Exclude any leftover report files
        after_paths = [f for f in after_paths if "download-report" not in f]
        files = sorted(set(printed_files + after_paths))
        print(f"[DEBUG] final files={files}", file=sys.stderr)

        if proc.returncode == 0 and files:
            record["status"] = "ok"
            record["files"] = files
            record["bytes"] = sum(Path(path).stat().st_size for path in files)
            return record

        tail = (proc.stderr or proc.stdout or "").strip().splitlines()
        record["note"] = (tail[-1] if tail else f"yt-dlp-exit-{proc.returncode}")[:300]
        if likely_cookie_fix(record["note"]) and not (cookies_file or browser_cookies):
            record["note"] += " | 可用 --cookies-file cookies.txt 重试"
        return record

    except subprocess.TimeoutExpired:
        record["note"] = f"yt-dlp-timeout-{timeout}s"
        return record
    except Exception as exc:
        record["note"] = str(exc)[:300]
        return record


def video_files_from_paths(paths: list[str]) -> list[str]:
    video_exts = {".mp4", ".webm", ".mov", ".m4v", ".mkv", ".flv", ".ogv"}
    result: list[str] = []
    for raw in paths:
        path = Path(raw.strip())
        if path.exists() and path.suffix.lower() in video_exts:
            result.append(str(path))
    return result


def escape_table(value: Any) -> str:
    return str(value or "").replace("|", "\\|").replace("\n", " ")


def write_reports(out_dir: Path, urls: list[str], records: list[dict[str, Any]]) -> None:
    payload = {
        "created_at": dt.datetime.now().isoformat(timespec="seconds"),
        "out_dir": str(out_dir),
        "urls": urls,
        "records": records,
    }
    (out_dir / "download-report.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    ok_count = sum(1 for record in records if record["status"] == "ok")
    lines = [
        "# 视频下载报告",
        "",
        f"- 输出目录：`{out_dir}`",
        f"- 链接数量：{len(records)}",
        f"- 成功：{ok_count}",
        f"- 失败：{len(records) - ok_count}",
        "",
        "| 状态 | 类型 | 平台 | 文件 | 大小 | 链接 | 备注 |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ]
    for record in records:
        files = "<br>".join(f"`{Path(path).name}`" for path in record.get("files", []))
        lines.append(
            "| "
            + " | ".join([
                escape_table(record.get("status", "")),
                escape_table(record.get("kind", "")),
                escape_table(record.get("platform", "")),
                files or "",
                escape_table(size_text(record.get("bytes") or None)),
                f"<{record.get('url', '')}>",
                escape_table(record.get("note", "")),
            ])
            + " |"
        )
    (out_dir / "download-report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Download videos from direct URLs and yt-dlp platforms."
    )
    parser.add_argument("urls", nargs="+", help="Video URLs")
    parser.add_argument("--out-root", default=str(DEFAULT_OUT_ROOT), help="Output root directory")
    parser.add_argument("--title", default="", help="Run title used in output folder name")
    parser.add_argument("--quality", default="1080", help="Max video height, e.g. 720/1080, or best")
    parser.add_argument("--max-video-mb", type=float, default=2000.0, help="Per video size limit")
    parser.add_argument("--cookies-file", default="", help="Cookies file path")
    parser.add_argument("--browser-cookies", default="", help="Browser name for cookies: chrome/safari/edge/firefox")
    parser.add_argument("--playlist", action="store_true", help="Allow playlist downloads")
    return parser.parse_args(argv or sys.argv[1:])


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    out_root = Path(args.out_root).expanduser()
    title = args.title or platform_name(args.urls[0]).lower()
    out_dir = make_run_dir(out_root, title)

    ytdlp_path = find_ytdlp()
    session = requests.Session()
    session.headers.update({"User-Agent": DEFAULT_USER_AGENT})

    seen: set[str] = set()
    urls: list[str] = []
    for url in args.urls:
        normalized = url.strip()
        if normalized and normalized not in seen:
            seen.add(normalized)
            urls.append(normalized)

    records: list[dict[str, Any]] = []
    for index, url in enumerate(urls, start=1):
        print(f"[{index}/{len(urls)}] {url}", flush=True)

        kind = classify_url(url)
        if kind == "direct":
            record = download_direct_video(
                session, url, out_dir,
                max_video_mb=args.max_video_mb,
                referer=url, timeout=60,
            )
        elif ytdlp_path is None:
            record = base_record(url, "platform")
            record["note"] = "yt-dlp not found — install via: pip install yt-dlp"
        else:
            record = download_with_ytdlp(
                url, out_dir,
                ytdlp_path=ytdlp_path,
                quality=args.quality,
                max_video_mb=args.max_video_mb,
                cookies_file=args.cookies_file,
                browser_cookies=args.browser_cookies,
                playlist=args.playlist,
                timeout=3600,
            )

        records.append(record)
        status = record["status"]
        note = f" ({record['note']})" if record.get("note") else ""
        print(f"  -> {status}{note}", flush=True)

    write_reports(out_dir, urls, records)

    ok_count = sum(1 for record in records if record["status"] == "ok")
    print(out_dir)
    print(f"videos_ok={ok_count}")
    print(f"videos_failed={len(records) - ok_count}")

    if ok_count == len(records):
        return 0
    if ok_count == 0:
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
