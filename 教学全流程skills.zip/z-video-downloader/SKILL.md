---
name: z-video-downloader
description: |
  视频下载技能。当用户给出视频链接并要求"下载视频""帮我把这个视频下下来""下载 YouTube 视频""下载 B站视频""下载 m3u8/mp4 直链""把视频保存到本地"时使用。
  支持 YouTube、Bilibili、Vimeo、X/Twitter、TikTok、抖音、Instagram、Facebook 等 yt-dlp 支持的平台，以及 mp4/webm/mov/mkv 直链视频。
  流程位置：教学全流程 Step 5（独立步骤，可在资源检索完成后衔接）。
  触发词："下载视频""视频下载""帮我把这个视频下下来""下载 YouTube/B站视频""视频保存到本地"。
---

# 视频下载器 V2 — CC 适配版

把用户给的视频链接下载成本地视频文件。核心实现来自 tjxj/z-skills，已适配 CC 工作环境。

## 联动衔接说明

本 skill 可在 `textbook-resource-workflow` 完成后衔接使用——资源检索报告中标注的视频资源链接，可交给本 skill 下载到本地。

**建议优先级**：YouTube 和直链 mp4 最可靠；B站、抖音、CCTV 可能需要额外操作。

## 依赖（全部已安装）

| 依赖 | 版本 | 路径 |
|------|------|------|
| Python (venv) | 3.13 | `/Users/a123/.workbuddy/binaries/python/envs/default/bin/python3` |
| yt-dlp | 2026.06.09 | venv pip 安装，`yt-dlp` 命令行 |
| ffmpeg | 7.1 | `/Users/a123/local/bin/ffmpeg`（imageio-ffmpeg symlink） |

### ffmpeg 安装方式（无 Homebrew）

```bash
# 1. pip 安装 imageio-ffmpeg
/Users/a123/.workbuddy/binaries/python/envs/default/bin/pip install imageio-ffmpeg

# 2. 获取 ffmpeg 二进制路径
/Users/a123/.workbuddy/binaries/python/envs/default/bin/python -c "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())"

# 3. 创建 symlink
mkdir -p /Users/a123/local/bin
ln -sf "<上一步输出的路径>" /Users/a123/local/bin/ffmpeg
```

## 执行流程

1. 确认用户给的是视频链接或视频直链。
2. 运行下载脚本：

```bash
/Users/a123/.workbuddy/binaries/python/envs/default/bin/python3 \
  /Users/a123/.workbuddy/skills/z-video-downloader/scripts/download_video.py \
  --title "课程主题名" \
  --out-root "/Users/a123/Downloads/6月27日直播/Video-Downloads" \
  "https://www.youtube.com/watch?v=xxx"
```

**⚠️ 重要参数**：
- `--out-root`：**必须指定可写目录**，不要用 `~/Desktop`（沙箱可能限制写入）
- `--title`：下载文件夹的主题名
- `--no-playlist`：默认不加 playlist，避免误下整套列表

3. 如果脚本报错 `python3.13 not found`，改用 venv Python：

```bash
/Users/a123/.workbuddy/binaries/python/envs/default/bin/python3 \
  /Users/a123/.workbuddy/skills/z-video-downloader/scripts/download_video.py \
  --out-root "<可写目录>" \
  --title "主题" \
  "URL"
```

4. 如果 yt-dlp 报错，可直接用 yt-dlp 命令行：

```bash
/Users/a123/.workbuddy/binaries/python/envs/default/bin/yt-dlp \
  --ffmpeg-location /Users/a123/local/bin \
  --no-playlist \
  -f "best[height<=1080]" \
  -o "<可写目录>/视频名.%(ext)s" \
  "URL"
```

5. 下载完成后读取 download-report.md，回复给用户。

## 平台策略与实战踩坑

### 可靠平台（首选）

| 平台 | 可下载性 | 备注 |
|------|---------|------|
| **YouTube** | ✅ **最可靠** | yt-dlp 直接支持，下载成功率最高 |
| **直链 mp4/webm** | ✅ 最可靠 | 脚本直接流式下载，无需 yt-dlp |
| **Vimeo** | ✅ 可靠 | yt-dlp 支持 |

### 不稳定平台（需要额外操作）

| 平台 | 问题 | 解决方案 |
|------|------|---------|
| **B站** | ⚠️ **经常触发412反爬** | 方案1：`--cookies-from-browser chrome` 重试；方案2：课堂直接播放链接，不强求下载 |
| **抖音** | ⚠️ 需要登录 cookies | 必须导出 cookies.txt 文件：`yt-dlp --cookies cookies.txt URL` |
| **X/Twitter** | ⚠️ 可能需要登录 | 同上，需要 cookies |
| **TikTok** | ⚠️ 区域限制 | 可能需要代理 |

### 不可下载平台

| 平台 | 问题 | 解决方案 |
|------|------|---------|
| **CCTV/央视网** | ❌ yt-dlp 不支持 | **只能课堂直接播放链接**，无法下载 |
| **网易公开课** | ❌ yt-dlp 不支持 | 同上 |

### 降级策略（实战总结）

下载失败时的标准降级路径：

```
1. 目标平台下载 → 失败
2. 尝试 cookies 重试（B站用 --cookies-from-browser chrome）→ 仍失败
3. 搜索 YouTube 同等内容视频 → 下载 YouTube 版本
4. YouTube 也无同等内容 → 标注"建议课堂直接播放链接"
5. 绝不无限重试，记录失败原因即可
```

**实战案例**：
- 3·15晚会视频：CCTV链接yt-dlp不支持 → B站412反爬 → 抖音需cookies → 最终在YouTube找到"小Lin说聊聊市场营销"替代下载成功
- **教训**：资源检索时优先找 YouTube 或直链 mp4 的视频源

## 沙箱写入限制

**⚠️ Desktop 目录可能被沙箱限制写入！**

- 默认输出目录 `~/Desktop/Video-Downloads` 在沙箱环境下可能无法创建
- **解决方案**：使用 `--out-root` 参数指定项目目录下的子文件夹：
  ```bash
  --out-root "/Users/a123/Downloads/6月27日直播/Video-Downloads"
  ```
- 下载完成后可手动 `cp` 到 Desktop（沙箱允许复制到已有目录）

## 默认输出结构

```text
<--out-root>/YYYY-MM-DD-主题/
├── 下载的视频文件.mp4
├── 下载的视频文件.info.json
├── download-report.md
└── download-report.json
```

## 注意事项

1. **ffmpeg 路径**：yt-dlp 需要通过 `--ffmpeg-location` 参数指定 ffmpeg 路径，或在 PATH 中包含 `/Users/a123/local/bin`。脚本已自动处理。
2. **Python 路径**：脚本中硬编码的 Python 路径已修正为 venv Python，不是系统 Python
3. **文件大小**：默认单视频不超过 2GB。下载长视频时可加 `--max-video-mb 5000`。
4. **直链优先**：如果是 `.mp4` 直链，无需 yt-dlp，直接流式下载。
5. **沙箱限制**：优先用 `--out-root` 指定可写目录，避免 Desktop 写入失败。
