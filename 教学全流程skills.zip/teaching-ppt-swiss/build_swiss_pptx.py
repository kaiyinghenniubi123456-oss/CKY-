# -*- coding: utf-8 -*-
"""
教学 PPT 生成器 V2 · 教学比赛风格
移植教学能力比赛国赛一等奖的视觉规律:
  - 5 大模块 + 21 固定版式
  - IKB 主色 + 朱红/麦黄 辅色 + 红黄高亮系统
  - 顶部导航条 + 章节色块
  - 图表用 PIL 手绘 (饼图/柱状图/雷达图/流程图)
  - 中文字体显式 eastAsia = PingFang SC
  - 全文中文标点
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn
from PIL import Image, ImageDraw, ImageFont
import os, io, datetime



# ============ 设计 token ============
INK      = RGBColor(0x0A, 0x0A, 0x0A)   # 近黑
PAPER    = RGBColor(0xFA, 0xFA, 0xF8)   # 极浅暖白
GREY_1   = RGBColor(0x2C, 0x3E, 0x50)   # 深灰(标题)
GREY_2   = RGBColor(0x7F, 0x8C, 0x8D)   # 正灰(辅助)
GREY_3   = RGBColor(0xBD, 0xC3, 0xC7)   # 浅灰(装饰线)
ACCENT   = RGBColor(0x00, 0x2F, 0xA7)   # IKB 克莱因蓝 (主色)
RED      = RGBColor(0xC8, 0x10, 0x2E)   # 朱红 (重点)
YELLOW   = RGBColor(0xF1, 0xC4, 0x0F)   # 麦黄 (二级重点)
GREEN    = RGBColor(0x27, 0xAE, 0x60)   # 翠绿 (数据上升/正面)
BLUE_LT  = RGBColor(0xE8, 0xEE, 0xF7)   # 浅蓝(色块底)
RED_LT   = RGBColor(0xFB, 0xE9, 0xEC)   # 浅红(色块底)
YEL_LT   = RGBColor(0xFE, 0xF9, 0xE7)   # 浅黄(色块底)
WHITE    = RGBColor(0xFF, 0xFF, 0xFF)

# 字体 (macOS 系统字体,跨平台时会自动回退)
SANS     = 'Helvetica Neue'
SANS_ZH  = 'PingFang SC'
SERIF_ZH = 'Songti SC'
MONO     = 'Menlo'

# 画布
W, H = 13.333, 7.5  # 16:9 标准

# 5 大模块元数据
MODULES = [
    ('01', '教学整体设计',  ACCENT),
    ('02', '教学实施过程',  RED),
    ('03', '学生学习效果',  GREEN),
    ('04', '特色亮点',      ACCENT),
    ('05', '反思改进措施',  GREY_1),
]

# ============ 底层工具函数 ============
def set_run_font(run, font_name=SANS_ZH, size=14, weight=400, color=INK,
                 bold=False, italic=False, underline=False):
    """设置 run 的字体(显式 eastAsia)"""
    run.font.name = font_name
    run.font.size = Pt(size)
    run.font.bold = bold or (weight >= 600)
    run.font.italic = italic
    run.font.underline = underline
    if color is not None:
        run.font.color.rgb = color
    # 关键: 显式设置东亚字体,避免中文回退到宋体
    rPr = run._r.get_or_add_rPr()
    # 移除已有的 eastAsia 节点
    for ea in rPr.findall(qn('a:ea')):
        rPr.remove(ea)
    ea = rPr.makeelement(qn('a:ea'), {'typeface': font_name})
    rPr.append(ea)
    # 设置 ASCII 字体
    for la in rPr.findall(qn('a:latin')):
        rPr.remove(la)
    la = rPr.makeelement(qn('a:latin'), {'typeface': SANS})
    rPr.insert(0, la)


def add_rect(slide, x, y, w, h, fill=WHITE, line=None, line_w=0.5):
    """直角矩形 (无圆角)"""
    shp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                                 Inches(x), Inches(y), Inches(w), Inches(h))
    shp.fill.solid()
    shp.fill.fore_color.rgb = fill
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line
        shp.line.width = Pt(line_w)
    shp.shadow.inherit = False
    return shp


def add_text(slide, x, y, w, h, text, size=14, weight=400, color=INK,
             align=PP_ALIGN.LEFT, font=None, anchor=MSO_ANCHOR.TOP,
             line_spacing=1.2):
    """单段文本"""
    if font is None:
        font = SANS_ZH
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = Inches(0)
    tf.margin_right = Inches(0)
    tf.margin_top = Inches(0)
    tf.margin_bottom = Inches(0)
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]
    p.alignment = align
    p.line_spacing = line_spacing
    run = p.add_run()
    run.text = text
    set_run_font(run, font_name=font, size=size, weight=weight, color=color)
    return tb


def add_multiline(slide, x, y, w, h, lines, font=SANS_ZH, line_spacing=1.4):
    """多行文本, lines 是 dict 列表 [{text, size, weight, color, bold, align}, ...]"""
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = Inches(0)
    tf.margin_right = Inches(0)
    tf.margin_top = Inches(0)
    tf.margin_bottom = Inches(0)
    for i, item in enumerate(lines):
        if isinstance(item, str):
            text = item
            size, weight, color, align = 16, 400, INK, PP_ALIGN.LEFT
            font_i = font
        else:
            text = item.get('text', '')
            size = item.get('size', 16)
            weight = item.get('weight', 400)
            color = item.get('color', INK)
            align = item.get('align', PP_ALIGN.LEFT)
            font_i = item.get('font', font)
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.line_spacing = line_spacing
        run = p.add_run()
        run.text = text
        set_run_font(run, font_name=font_i, size=size, weight=weight, color=color)
    return tb


def add_hairline(slide, x, y, w, h, color=GREY_3, weight=0.5):
    """1px 发丝线"""
    line = slide.shapes.add_connector(1, Inches(x), Inches(y), Inches(x+w), Inches(y))
    line.line.color.rgb = color
    line.line.width = Pt(weight)
    return line


def add_pic(slide, img_bytes, x, y, w=None, h=None):
    """插入图片 (PIL Image 转 bytes)"""
    bio = io.BytesIO()
    img_bytes.save(bio, format='PNG')
    bio.seek(0)
    if w and h:
        return slide.shapes.add_picture(bio, Inches(x), Inches(y), Inches(w), Inches(h))
    elif w:
        return slide.shapes.add_picture(bio, Inches(x), Inches(y), width=Inches(w))
    elif h:
        return slide.shapes.add_picture(bio, Inches(x), Inches(y), height=Inches(h))
    return slide.shapes.add_picture(bio, Inches(x), Inches(y))


# ============ 导航条 (每页顶部) ============
def add_nav(slide, current_module_idx):
    """顶部导航条: 5 大模块水平排列,当前模块高亮"""
    # 背景条
    add_rect(slide, 0, 0, W, 0.42, fill=PAPER)
    add_hairline(slide, 0, 0.42, W, 0, color=ACCENT, weight=1.0)

    x_start = 0.5
    for i, (num, name, color) in enumerate(MODULES):
        x = x_start + i * 2.5
        is_current = (i == current_module_idx)
        # 编号
        add_text(slide, x, 0.08, 0.4, 0.3, num,
                 size=11, weight=600,
                 color=color if is_current else GREY_2,
                 align=PP_ALIGN.LEFT)
        # 名称
        add_text(slide, x + 0.4, 0.08, 2.0, 0.3, name,
                 size=12, weight=600 if is_current else 400,
                 color=color if is_current else GREY_2,
                 align=PP_ALIGN.LEFT)
        if is_current:
            # 当前模块底部红/蓝色短粗下划线
            add_rect(slide, x, 0.36, 0.4, 0.06, fill=color)


def add_page_num(slide, num, total):
    """右下角页码"""
    add_text(slide, W - 1.5, H - 0.4, 1.2, 0.3,
             f'{num:02d} / {total:02d}',
             size=10, weight=400, color=GREY_2,
             align=PP_ALIGN.RIGHT, font=MONO)


def add_corner_mark(slide, text='教学比赛课件 · 2026'):
    """右下角署名"""
    add_text(slide, 0.5, H - 0.4, 4, 0.3, text,
             size=10, weight=400, color=GREY_2,
             align=PP_ALIGN.LEFT, font=SANS_ZH)


# ============ PIL 图表函数 ============

def _P(method_name, d, *args, **kw):
    """PIL wrapper: 把第一个 list 参数内的数字都 int 化"""
    if args and isinstance(args[0], (list, tuple)):
        new_xy = []
        for item in args[0]:
            if isinstance(item, (list, tuple)):
                new_xy.append(tuple(int(v) if isinstance(v, (int, float)) else v for v in item))
            elif isinstance(item, (int, float)):
                new_xy.append(int(item))
            else:
                new_xy.append(item)
        args = (new_xy,) + args[1:]
    method = getattr(d, method_name)
    return method(*args, **kw)


def chart_pie(segments, title='', size=(400, 300), palette=None):
    """手绘饼图. segments = [(label, value, color_hex), ...]"""
    if palette is None:
        palette = ['#002FA7', '#C8102E', '#F1C40F', '#27AE60', '#7F8C8D', '#9B59B6', '#1ABC9C']
    w, h = size
    img = Image.new('RGB', (w, h), '#FAFAF8')
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 14)
        font_sm = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 12)
        font_title = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 16)
    except:
        font = font_sm = font_title = ImageFont.load_default()

    total = sum(v for _, v, _ in segments)
    if total == 0:
        return img
    cx, cy, r = w // 3, h // 2 + 10, min(w // 3, h // 2) - 30
    start = -90
    for i, (label, value, color) in enumerate(segments):
        end = start + value / total * 360
        _P("pieslice", d, [cx-r, cy-r, cx+r, cy+r], start, end, fill=color, outline='#FAFAF8', width=int(2))
        start = end

    # 图例
    lx = cx + r + 30
    ly = 40
    for i, (label, value, color) in enumerate(segments):
        _P("rectangle", d, [lx, ly + i*28, lx+18, ly+18+i*28], fill=color)
        pct = value / total * 100
        d.text((lx+26, ly-2+i*28), f'{label}  {pct:.0f}%', fill='#0A0A0A', font=font_sm)

    if title:
        d.text((20, 15), title, fill='#0A0A0A', font=font_title)
    return img


def chart_bar(data, title='', size=(600, 300), ylabel='', color='#002FA7'):
    """手绘柱状图. data = [(label, value), ...]"""
    w, h = size
    img = Image.new('RGB', (w, h), '#FAFAF8')
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 13)
        font_sm = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 11)
    except:
        font = font_sm = ImageFont.load_default()

    if not data:
        return img
    max_v = max(v for _, v in data) or 1
    pad_l, pad_r, pad_t, pad_b = 60, 20, 30, 50
    cw = (w - pad_l - pad_r) / len(data)
    bar_w = cw * 0.55

    # y 轴
    _P("line", d, [(pad_l, pad_t), (pad_l, h-pad_b)], fill='#7F8C8D', width=int(1))
    # x 轴
    _P("line", d, [(pad_l, h-pad_b), (w-pad_r, h-pad_b)], fill='#7F8C8D', width=int(1))

    # 网格线
    for i in range(1, 5):
        y = h - pad_b - (h - pad_t - pad_b) * i / 5
        _P("line", d, [(pad_l, y), (w-pad_r, y)], fill='#E0E0E0', width=int(0.5))
        d.text((5, y-8), f'{int(max_v*i/5)}', fill='#7F8C8D', font=font_sm)

    # 柱
    for i, (label, value) in enumerate(data):
        x = pad_l + cw * i + (cw - bar_w) / 2
        bh = (h - pad_t - pad_b) * value / max_v
        _P("rectangle", d, [x, h-pad_b-bh, x+bar_w, h-pad_b], fill=color, outline=None)
        # 数值
        d.text((x+bar_w/2-12, h-pad_b-bh-22), f'{value}', fill='#0A0A0A', font=font)
        # 标签
        d.text((x, h-pad_b+8), label, fill='#0A0A0A', font=font_sm)

    if title:
        d.text((20, 5), title, fill='#0A0A0A', font=font)
    if ylabel:
        d.text((5, pad_t), ylabel, fill='#7F8C8D', font=font_sm)
    return img


def chart_radar(data, title='', size=(400, 400), color='#002FA7'):
    """手绘雷达图. data = [(label, value, max), ...]"""
    import math
    w, h = size
    img = Image.new('RGB', (w, h), '#FAFAF8')
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 13)
    except:
        font = ImageFont.load_default()

    cx, cy = w // 2, h // 2 + 10
    r = min(w, h) // 2 - 50
    n = len(data)
    if n < 3:
        return img

    # 同心多边形
    for level in [0.25, 0.5, 0.75, 1.0]:
        pts = []
        for i in range(n):
            angle = -math.pi / 2 + 2 * math.pi * i / n
            x = cx + r * level * math.cos(angle)
            y = cy + r * level * math.sin(angle)
            pts.append((x, y))
        _P("polygon", d, pts, outline='#BDC3C7', fill=None)

    # 辐射线
    for i in range(n):
        angle = -math.pi / 2 + 2 * math.pi * i / n
        x = cx + r * math.cos(angle)
        y = cy + r * math.sin(angle)
        _P("line", d, [(cx, cy), (x, y)], fill='#BDC3C7', width=int(0.5))

    # 数据
    pts = []
    for i, (label, value, mx) in enumerate(data):
        angle = -math.pi / 2 + 2 * math.pi * i / n
        ratio = value / mx if mx else 0
        x = cx + r * ratio * math.cos(angle)
        y = cy + r * ratio * math.sin(angle)
        pts.append((x, y))
        # 标签
        lx = cx + (r + 25) * math.cos(angle)
        ly = cy + (r + 25) * math.sin(angle)
        d.text((lx-15, ly-8), label, fill='#0A0A0A', font=font)
    _P("polygon", d, pts, outline=color, fill=color)
    # 填充半透明 (简化为浅色填充)
    # 重新画一次,加透明度
    overlay = Image.new('RGBA', img.size, (0, 0, 0, 0))
    od = ImageDraw.Draw(overlay)
    r_, g_, b_ = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
    od.polygon(pts, fill=(r_, g_, b_, 60))
    img = Image.alpha_composite(img.convert('RGBA'), overlay).convert('RGB')
    d = ImageDraw.Draw(img)

    if title:
        d.text((20, 5), title, fill='#0A0A0A', font=font)
    return img


def chart_flow(steps, title='', size=(800, 200), color='#002FA7'):
    """手绘横向流程图. steps = [step1, step2, ...]"""
    w, h = size
    img = Image.new('RGB', (w, h), '#FAFAF8')
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 13)
    except:
        font = ImageFont.load_default()

    n = len(steps)
    pad = 20
    box_w = (w - pad*2) / n
    box_h = 60
    cy = h // 2
    for i, step in enumerate(steps):
        x = pad + box_w * i + 5
        y = cy - box_h // 2
        _P("rectangle", d, [x, y, x+box_w-10, y+box_h], fill=color, outline=None)
        # 文字
        try:
            tw = d.textlength(step, font=font)
        except:
            tw = len(step) * 8
        d.text((x + (box_w-10-tw)/2, y + box_h//2 - 8), step, fill='white', font=font)
        # 箭头
        if i < n - 1:
            ax = x + box_w - 10
            ay = cy
            _P("polygon", d, [(ax, ay-6), (ax+12, ay), (ax, ay+6)], fill='#7F8C8D')

    if title:
        d.text((20, 5), title, fill='#0A0A0A', font=font)
    return img


# ============ 公共页眉 ============
def setup_slide(slide, module_idx, page_num, total_pages, title='', subtitle=''):
    """每页标准页眉: 导航条 + 标题 + 副标题 + 页码"""
    add_nav(slide, module_idx)
    if title:
        # 模块色块标记
        module_color = MODULES[module_idx][2]
        add_rect(slide, 0.5, 0.7, 0.15, 0.5, fill=module_color)
        add_text(slide, 0.8, 0.65, 9, 0.6, title,
                 size=28, weight=600, color=INK, font=SANS_ZH)
    if subtitle:
        add_text(slide, 0.8, 1.25, 9, 0.4, subtitle,
                 size=14, weight=300, color=GREY_2, font=SANS_ZH)
    # 内容区起始 y = 1.8
    add_page_num(slide, page_num, total_pages)


# ============ 21 个版式实现 ============
def slide_01_cover(prs, course_name, school, teacher, signin_qr=False):
    """P1 封面"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    # 满屏 IKB 蓝底
    add_rect(s, 0, 0, W, H, fill=ACCENT)

    # 顶部品牌行
    add_text(s, 0.6, 0.4, 8, 0.4, '教学能力比赛 · 参赛作品',
             size=12, weight=400, color=WHITE, font=SANS_ZH)
    add_text(s, W-3, 0.4, 2.4, 0.4, datetime.date.today().strftime('%Y'),
             size=12, weight=400, color=WHITE, font=SANS_ZH, align=PP_ALIGN.RIGHT)

    # 主标题 - 极细巨字
    add_text(s, 0.6, 1.6, 12, 1.2, course_name,
             size=64, weight=200, color=WHITE, font=SANS_ZH)
    add_text(s, 0.6, 2.9, 12, 0.5, 'Teaching Design & Implementation Report',
             size=14, weight=300, color=YELLOW, font=SANS)

    # 分隔线
    add_hairline(s, 0.6, 3.8, 4, 0, color=WHITE, weight=1.0)

    # 学校 + 教师
    add_text(s, 0.6, 4.0, 8, 0.4, school,
             size=18, weight=400, color=WHITE, font=SANS_ZH)
    add_text(s, 0.6, 4.5, 8, 0.4, f'参赛教师：{teacher}',
             size=14, weight=300, color=WHITE, font=SANS_ZH)

    # 课程模块信息
    add_text(s, 0.6, 5.6, 12, 0.4, '5 大模块 · 21 个版式 · IKB 教学设计体系',
             size=12, weight=300, color=WHITE, font=SANS_ZH)

    # 雨课堂二维码占位 (右下)
    if signin_qr:
        add_rect(s, W-1.7, H-2.0, 1.2, 1.2, fill=WHITE)
        add_text(s, W-1.7, H-0.7, 1.2, 0.3, '雨课堂签到',
                 size=10, weight=400, color=WHITE, font=SANS_ZH, align=PP_ALIGN.CENTER)


def slide_02_toc(prs, total_pages, current_page):
    """P2 目录 - 5 大模块带数字编号"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 0, current_page, total_pages, title='目  录', subtitle='CONTENTS')

    # 5 大模块水平卡片
    card_w = 2.3
    card_h = 4.5
    y = 2.0
    x_start = 0.7
    gap = 0.15
    for i, (num, name, color) in enumerate(MODULES):
        x = x_start + i * (card_w + gap)
        # 卡片
        add_rect(s, x, y, card_w, card_h, fill=PAPER, line=color, line_w=0.75)
        # 顶部色块
        add_rect(s, x, y, card_w, 1.6, fill=color)
        # 编号大字
        add_text(s, x+0.2, y+0.3, card_w-0.4, 1.0, num,
                 size=72, weight=200, color=WHITE, font=SANS)
        # 名称
        add_text(s, x+0.2, y+1.7, card_w-0.4, 0.4, name,
                 size=18, weight=600, color=INK, font=SANS_ZH, align=PP_ALIGN.CENTER)
        # 描述
        descs = [
            '内容重构 · 学情 · 目标 · 策略 · 评价',
            '流程 · 课前 · 课中 · 课后',
            '成绩 · 作品 · 证书',
            '创新 · 思政 · 跨学科',
            '问题 · 措施',
        ]
        add_multiline(s, x+0.2, y+2.4, card_w-0.4, 2.0, [
            {'text': d, 'size': 12, 'weight': 300, 'color': GREY_2}
            for d in descs[i].split(' · ')
        ], line_spacing=1.5)


def slide_03_section_divider(prs, module_idx, total_pages, current_page):
    """P3 章节过渡页 - 满屏主色 + 反白大号"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    num, name, color = MODULES[module_idx]
    add_rect(s, 0, 0, W, H, fill=color)
    # 大编号
    add_text(s, 0.8, 1.5, 4, 3, num,
             size=240, weight=200, color=WHITE, font=SANS)
    # 模块名
    add_text(s, 5.0, 2.8, 8, 1.0, name,
             size=54, weight=300, color=WHITE, font=SANS_ZH)
    # 英文
    en_names = ['OVERALL DESIGN', 'IMPLEMENTATION', 'STUDENT OUTCOMES', 'HIGHLIGHTS', 'REFLECTION']
    add_text(s, 5.0, 3.9, 8, 0.4, en_names[module_idx],
             size=14, weight=400, color=YELLOW, font=SANS)
    # 章节内容预述
    add_hairline(s, 5.0, 4.5, 2, 0, color=WHITE, weight=1.0)
    pres = [
        '内容重构 / 学情 / 目标 / 策略 / 评价',
        '教学流程 / 课前 / 课中 / 课后',
        '成绩提升 / 作品 / 证书',
        '创新举措 / 思政融入 / 跨学科',
        '问题剖析 / 改进措施',
    ]
    add_text(s, 5.0, 4.7, 8, 0.4, pres[module_idx],
             size=14, weight=300, color=WHITE, font=SANS_ZH)

    # 章节页不显示顶部导航条 (视觉清空)


def slide_04_xueqing(prs, current_page, total_pages):
    """P4 学情分析 - 三件套图表"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 0, current_page, total_pages, title='学情分析',
                subtitle='基于班级 38 人线上线下数据，精准把握学情')

    # 左侧: 饼图
    pie = chart_pie([
        ('已掌握基础知识', 28, '#002FA7'),
        ('部分掌握,需复习', 7, '#C8102E'),
        ('完全未接触', 3, '#F1C40F'),
    ], title='基础知识掌握度', size=(480, 320))
    add_pic(s, pie, 0.5, 2.0, w=4.5)

    # 右侧: 柱状图
    bar = chart_bar([
        ('学习态度', 4.2), ('基础知识', 3.8), ('实操能力', 3.0),
        ('协作意识', 4.5), ('表达展示', 2.8), ('拓展学习', 2.5),
    ], title='能力维度自评 (5 分制)', size=(600, 320), color='#002FA7')
    add_pic(s, bar, 5.5, 2.0, w=7.0)

    # 底部: 文字分析
    add_rect(s, 0.5, 5.6, 12.3, 1.4, fill=BLUE_LT)
    add_rect(s, 0.5, 5.6, 0.1, 1.4, fill=ACCENT)
    add_multiline(s, 0.8, 5.7, 12, 1.3, [
        {'text': '共性特点：', 'size': 14, 'weight': 600, 'color': ACCENT},
        {'text': '本班学生基础知识掌握较好 (74%)，学习态度积极 (4.2/5)，但实操能力 (3.0) 和表达展示 (2.8) 偏弱，对新工具 (AI 辅助) 接受度高。', 'size': 14, 'weight': 300, 'color': INK},
    ], line_spacing=1.4)
    add_multiline(s, 0.8, 6.4, 12, 0.6, [
        {'text': '预估困难：', 'size': 14, 'weight': 600, 'color': RED},
        {'text': '复杂任务拆解、独立完成项目、从"做"到"讲"的转化。', 'size': 14, 'weight': 300, 'color': INK},
    ], line_spacing=1.4)


def slide_05_objectives(prs, current_page, total_pages):
    """P5 教学目标 - 知识/能力/素质三栏"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 0, current_page, total_pages, title='教学目标',
                subtitle='依据专业教学标准 + 岗位需求 + 1+X 证书要求')

    # 三栏
    cols = [
        ('知 识', 'KNOWLEDGE', ACCENT, [
            '掌握 12 个核心概念',
            '理解 5 个工具的基本原理',
            '能复述 3R 体系内涵',
        ]),
        ('能 力', 'ABILITY', RED, [
            '能独立完成 1 份市场调研',
            '能设计 1 套营销方案',
            '能向客户清晰呈现',
        ]),
        ('素 质', 'QUALITY', GREEN, [
            '树立客户中心意识',
            '养成数据驱动习惯',
            '培育创新创业精神',
        ]),
    ]
    col_w = 4.0
    gap = 0.15
    y = 2.0
    h = 4.5
    x_start = (W - col_w * 3 - gap * 2) / 2
    for i, (title_zh, title_en, color, items) in enumerate(cols):
        x = x_start + i * (col_w + gap)
        # 卡片
        add_rect(s, x, y, col_w, h, fill=PAPER, line=color, line_w=0.75)
        # 顶部色块
        add_rect(s, x, y, col_w, 1.2, fill=color)
        # 标题
        add_text(s, x+0.3, y+0.15, col_w-0.6, 0.5, title_zh,
                 size=24, weight=600, color=WHITE, font=SANS_ZH)
        add_text(s, x+0.3, y+0.7, col_w-0.6, 0.3, title_en,
                 size=12, weight=400, color=WHITE, font=SANS)
        # 列表
        item_y = y + 1.5
        for j, item in enumerate(items):
            add_rect(s, x+0.3, item_y+0.15, 0.15, 0.15, fill=color)
            add_text(s, x+0.6, item_y, col_w-0.8, 0.5, item,
                     size=14, weight=400, color=INK, font=SANS_ZH)
            item_y += 0.7


def slide_06_keypoints(prs, current_page, total_pages):
    """P6 教学重难点 - 左右对比"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 0, current_page, total_pages, title='教学重难点',
                subtitle='基于学情分析 + 课程标准 + 行业反馈')

    # 左: 重点
    x_l, x_r = 0.5, 6.85
    col_w = 5.98
    y = 2.0
    h = 4.6
    # 重点
    add_rect(s, x_l, y, col_w, h, fill=BLUE_LT)
    add_rect(s, x_l, y, 0.1, h, fill=ACCENT)
    add_text(s, x_l+0.3, y+0.2, 2, 0.6, '重  点',
             size=36, weight=200, color=ACCENT, font=SANS_ZH)
    add_text(s, x_l+0.3, y+0.95, 3, 0.4, 'KEY POINTS',
             size=11, weight=400, color=ACCENT, font=SANS)
    add_multiline(s, x_l+0.3, y+1.6, col_w-0.5, 2.5, [
        {'text': '01  营销观念的 5 阶段演变', 'size': 16, 'weight': 500, 'color': INK},
        {'text': '02  客户需求的识别方法', 'size': 16, 'weight': 500, 'color': INK},
        {'text': '03  营销组合 4P 工具应用', 'size': 16, 'weight': 500, 'color': INK},
    ], line_spacing=2.0)
    add_text(s, x_l+0.3, y+4.2, col_w-0.5, 0.3, '依据：专业教学标准 + 1+X 证书',
             size=12, weight=300, color=GREY_2, font=SANS_ZH)

    # 难点
    add_rect(s, x_r, y, col_w, h, fill=RED_LT)
    add_rect(s, x_r, y, 0.1, h, fill=RED)
    add_text(s, x_r+0.3, y+0.2, 2, 0.6, '难  点',
             size=36, weight=200, color=RED, font=SANS_ZH)
    add_text(s, x_r+0.3, y+0.95, 3, 0.4, 'DIFFICULTIES',
             size=11, weight=400, color=RED, font=SANS)
    add_multiline(s, x_r+0.3, y+1.6, col_w-0.5, 2.5, [
        {'text': '01  从"产品导向"到"客户导向"的思维转换', 'size': 16, 'weight': 500, 'color': INK},
        {'text': '02  社会营销观念与企业短期利益的平衡', 'size': 16, 'weight': 500, 'color': INK},
        {'text': '03  客户隐性需求的挖掘', 'size': 16, 'weight': 500, 'color': INK},
    ], line_spacing=2.0)
    add_text(s, x_r+0.3, y+4.2, col_w-0.5, 0.3, '依据：学情薄弱环节 + 历届学生反馈',
             size=12, weight=300, color=GREY_2, font=SANS_ZH)


def slide_07_strategy(prs, current_page, total_pages):
    """P7 教学策略 - 流程图 + 思政"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 0, current_page, total_pages, title='教学策略',
                subtitle='"三阶六环"任务驱动 + 课程思政融入')

    # 上方: 流程图
    flow = chart_flow(['课前 预习导学', '课中 任务驱动', '课后 拓展提升', '评价 多元反馈'],
                      size=(1100, 130), color='#002FA7')
    add_pic(s, flow, 0.7, 2.0, w=12)

    # 下方左: 教学方法
    add_text(s, 0.5, 3.7, 6, 0.4, '教学方法',
             size=18, weight=600, color=ACCENT, font=SANS_ZH)
    add_multiline(s, 0.5, 4.2, 6, 2.8, [
        {'text': '■ 案例教学法', 'size': 14, 'weight': 500, 'color': INK},
        {'text': '   真实企业案例贯穿 4 节课', 'size': 12, 'weight': 300, 'color': GREY_2},
        {'text': '■ 任务驱动法', 'size': 14, 'weight': 500, 'color': INK},
        {'text': '   4 人小组合作完成 1 份方案', 'size': 12, 'weight': 300, 'color': GREY_2},
        {'text': '■ 角色扮演法', 'size': 14, 'weight': 500, 'color': INK},
        {'text': '   客户与营销员对话演练', 'size': 12, 'weight': 300, 'color': GREY_2},
    ], line_spacing=1.6)

    # 下方右: 思政融入
    add_text(s, 7.0, 3.7, 6, 0.4, '课程思政融入',
             size=18, weight=600, color=RED, font=SANS_ZH)
    add_multiline(s, 7.0, 4.2, 6, 2.8, [
        {'text': '★ 诚信营销', 'size': 14, 'weight': 500, 'color': INK},
        {'text': '   "绝不在客户面前说同行坏话"', 'size': 12, 'weight': 300, 'color': GREY_2},
        {'text': '★ 工匠精神', 'size': 14, 'weight': 500, 'color': INK},
        {'text': '   拜访客户前的资料准备细节', 'size': 12, 'weight': 300, 'color': GREY_2},
        {'text': '★ 文化自信', 'size': 14, 'weight': 500, 'color': INK},
        {'text': '   老字号品牌的营销智慧案例', 'size': 12, 'weight': 300, 'color': GREY_2},
    ], line_spacing=1.6)


def slide_08_evaluation(prs, current_page, total_pages):
    """P8 教学评价 - 多元评价体系"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 0, current_page, total_pages, title='教学评价',
                subtitle='过程性评价 (60%) + 终结性评价 (40%)  ·  关注增值表现')

    # 左: 饼图 - 评价构成
    pie = chart_pie([
        ('过程性评价', 60, '#002FA7'),
        ('终结性评价', 40, '#C8102E'),
    ], title='评价构成', size=(450, 320))
    add_pic(s, pie, 0.5, 2.0, w=4.5)

    # 右: 雷达图 - 能力维度
    radar = chart_radar([
        ('知识', 4.2, 5), ('技能', 3.8, 5), ('态度', 4.5, 5),
        ('协作', 4.0, 5), ('创新', 3.5, 5), ('表达', 3.6, 5),
    ], title='班级能力增值雷达 (5 分制)', size=(450, 380), color='#002FA7')
    add_pic(s, radar, 5.5, 2.0, w=4.5)

    # 底部: 4 个指标卡
    metrics = [
        ('学习兴趣', '+38%', GREEN),
        ('课堂参与', '+45%', ACCENT),
        ('任务完成率', '92%', ACCENT),
        ('技能考证', '1+X 通过', RED),
    ]
    x = 0.5
    for label, val, color in metrics:
        add_rect(s, x, 5.5, 2.95, 1.4, fill=PAPER, line=color, line_w=1.0)
        add_text(s, x+0.2, 5.65, 2.75, 0.4, label,
                 size=14, weight=500, color=GREY_2, font=SANS_ZH)
        add_text(s, x+0.2, 6.05, 2.75, 0.7, val,
                 size=28, weight=600, color=color, font=SANS)
        x += 3.15


def slide_09_flowchart(prs, current_page, total_pages):
    """P9 整体教学流程图 - 16 学时"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 1, current_page, total_pages, title='整体教学流程',
                subtitle='16 学时 · 4 大任务 · 校企双元交替')

    # 大幅流程图 (4 任务 16 学时)
    add_text(s, 0.5, 1.9, 12, 0.4, '总览：4 个任务 × 4 学时 = 16 学时',
             size=14, weight=400, color=GREY_2, font=SANS_ZH)

    # 4 任务大卡片
    tasks = [
        ('任务 1', '树立营销理念', '4 学时', ACCENT),
        ('任务 2', '分析市场机会', '4 学时', RED),
        ('任务 3', '制定营销组合', '4 学时', GREEN),
        ('任务 4', '管理客户关系', '4 学时', ACCENT),
    ]
    x = 0.5
    for i, (num, name, hrs, color) in enumerate(tasks):
        add_rect(s, x, 2.6, 2.95, 1.5, fill=color)
        add_text(s, x+0.2, 2.7, 2.75, 0.4, num,
                 size=14, weight=600, color=YELLOW, font=SANS_ZH)
        add_text(s, x+0.2, 3.1, 2.75, 0.5, name,
                 size=18, weight=600, color=WHITE, font=SANS_ZH)
        add_text(s, x+0.2, 3.65, 2.75, 0.3, hrs,
                 size=12, weight=300, color=WHITE, font=SANS_ZH)
        # 箭头
        if i < 3:
            add_text(s, x+2.95, 3.2, 0.2, 0.4, '→',
                     size=24, weight=300, color=GREY_2, font=SANS, align=PP_ALIGN.CENTER)
        x += 3.15

    # 16 学时详细
    details = [
        ('1-2', '导入 + 概念'), ('3-4', '观念对比 + 练习'),
        ('5-6', '市场调研方法'), ('7-8', '调研实施'),
        ('9-10', '4P 组合'), ('11-12', '方案设计'),
        ('13-14', '客户管理'), ('15-16', '总结 + 答辩'),
    ]
    y = 4.5
    for i, (clk, name) in enumerate(details):
        cx = 0.5 + (i % 4) * 3.15
        cy = y + (i // 4) * 1.0
        add_rect(s, cx, cy, 2.95, 0.85, fill=PAPER, line=GREY_3, line_w=0.5)
        add_rect(s, cx, cy, 0.5, 0.85, fill=color)
        add_text(s, cx+0.6, cy+0.1, 0.8, 0.3, clk,
                 size=12, weight=600, color=color, font=MONO)
        add_text(s, cx+0.6, cy+0.4, 2.3, 0.4, name,
                 size=12, weight=400, color=INK, font=SANS_ZH)


def slide_10_kqian(prs, current_page, total_pages):
    """P10 课前 - 预习导学"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 1, current_page, total_pages, title='课前 · 预习导学',
                subtitle='发布学习任务单 + 雨课堂推送预习资料')

    # 三列: 任务 / 数据 / 资源
    cols = [
        ('学习任务', ACCENT, [
            '观看 5 分钟微课视频',
            '完成 3 道基础概念题',
            '提交 1 个生活案例',
        ]),
        ('完成数据', GREEN, [
            {'text': '视频完成率  ', 'size': 14, 'weight': 500},
            {'text': '97% (37/38)', 'size': 18, 'weight': 700, 'color': GREEN},
            {'text': '测试平均分  ', 'size': 14, 'weight': 500},
            {'text': '82 分', 'size': 18, 'weight': 700, 'color': GREEN},
        ]),
        ('推送资源', ACCENT, [
            '微课视频 (5min)',
            '任务单 PDF',
            '案例库链接',
            '雨课堂讨论区',
        ]),
    ]
    col_w = 4.0
    y = 2.0
    h = 4.5
    for i, (title, color, items) in enumerate(cols):
        x = 0.5 + i * (col_w + 0.15)
        add_rect(s, x, y, col_w, h, fill=PAPER, line=color, line_w=0.75)
        add_rect(s, x, y, col_w, 0.6, fill=color)
        add_text(s, x+0.3, y+0.12, col_w-0.6, 0.4, title,
                 size=16, weight=600, color=WHITE, font=SANS_ZH)
        item_y = y + 1.0
        for item in items:
            if isinstance(item, dict):
                add_text(s, x+0.3, item_y, col_w-0.6, 0.4, item.get('text',''),
                         size=item.get('size',14), weight=item.get('weight',500),
                         color=item.get('color',INK), font=SANS_ZH)
                item_y += 0.5
            else:
                add_rect(s, x+0.3, item_y+0.15, 0.1, 0.1, fill=color)
                add_text(s, x+0.5, item_y, col_w-0.8, 0.4, item,
                         size=14, weight=400, color=INK, font=SANS_ZH)
                item_y += 0.55


def slide_11_kzhong_intro(prs, current_page, total_pages):
    """P11 课中-导入 (案例/视频)"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 1, current_page, total_pages, title='课中 · 案例导入',
                subtitle='从"舌尖上的中国"看金华火腿')

    # 左侧: 案例描述
    add_text(s, 0.5, 2.0, 7, 0.4, '案例背景',
             size=18, weight=600, color=ACCENT, font=SANS_ZH)
    add_multiline(s, 0.5, 2.5, 7, 4.5, [
        {'text': '《舌尖上的中国》金华火腿片段', 'size': 16, 'weight': 500, 'color': INK},
        {'text': '   肌红脂白、盐腌日晒、24 月发酵', 'size': 14, 'weight': 300, 'color': GREY_2},
        {'text': '', 'size': 6},
        {'text': '为什么添加亚硝酸盐？', 'size': 16, 'weight': 600, 'color': RED, 'bold': True},
        {'text': '   护色 / 抑菌 / 改善风味', 'size': 14, 'weight': 300, 'color': INK},
        {'text': '', 'size': 6},
        {'text': '为什么会有致癌风险？', 'size': 16, 'weight': 600, 'color': RED, 'bold': True},
        {'text': '   急性毒性 + 慢性毒性', 'size': 14, 'weight': 300, 'color': INK},
        {'text': '', 'size': 6},
        {'text': '如何检测与防控？', 'size': 16, 'weight': 600, 'color': YELLOW, 'bold': True},
        {'text': '   本节课的 3R 体系即将展开', 'size': 14, 'weight': 300, 'color': INK},
    ], line_spacing=1.4)

    # 右侧: 视频/图片占位
    add_rect(s, 8.0, 2.0, 4.8, 3.2, fill=BLUE_LT, line=ACCENT, line_w=1.0)
    add_text(s, 8.0, 2.0, 4.8, 3.2, '▶\n\n视频播放区\n(可插入本地视频)',
             size=14, weight=400, color=GREY_2, font=SANS_ZH,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

    # 思政融入 (右下)
    add_rect(s, 8.0, 5.4, 4.8, 1.0, fill=YEL_LT, line=YELLOW, line_w=0.5)
    add_text(s, 8.2, 5.5, 4.5, 0.3, '★ 课程思政',
             size=12, weight=600, color=RED, font=SANS_ZH)
    add_text(s, 8.2, 5.8, 4.5, 0.5,
             '剂量决定毒性 — 科学的边界就是安全',
             size=13, weight=400, color=INK, font=SANS_ZH)


def slide_12_kzhong_explain(prs, current_page, total_pages):
    """P12 课中-讲解 (难点+红色高亮)"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 1, current_page, total_pages, title='课中 · 难点突破',
                subtitle='"不能脱离剂量谈毒性"')

    # 主区: 方程 + 解读
    add_text(s, 0.5, 1.9, 12, 0.4, '核心概念：',
             size=16, weight=600, color=ACCENT, font=SANS_ZH)
    add_text(s, 0.5, 2.4, 12, 0.8,
             '亚硝酸盐 ＝ 危险 (脱离剂量)  ↔  安全 (合理剂量)',
             size=32, weight=300, color=INK, font=SANS_ZH)

    # 黄色高亮: "剂量" "毒性"
    add_rect(s, 1.6, 2.65, 1.5, 0.5, fill=YELLOW)
    add_text(s, 1.6, 2.65, 1.5, 0.5, '剂量',
             size=28, weight=700, color=INK, font=SANS_ZH, align=PP_ALIGN.CENTER)
    add_rect(s, 4.6, 2.65, 1.5, 0.5, fill=YELLOW)
    add_text(s, 4.6, 2.65, 1.5, 0.5, '毒性',
             size=28, weight=700, color=INK, font=SANS_ZH, align=PP_ALIGN.CENTER)

    # 红色警示词
    add_text(s, 0.5, 3.5, 12, 0.4,
             '剂量反应模型 (Weibull 分布):',
             size=16, weight=600, color=RED, font=SANS_ZH)

    # 左侧: 曲线图 (手绘 placeholder)
    add_rect(s, 0.5, 4.0, 6.0, 2.7, fill=BLUE_LT, line=ACCENT, line_w=0.5)
    add_text(s, 0.5, 4.0, 6.0, 2.7, '剂量-反应曲线图\n(占位)',
             size=14, weight=400, color=GREY_2, font=SANS_ZH,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

    # 右侧: 解读
    add_text(s, 6.8, 4.0, 6, 0.4, '学科思想',
             size=16, weight=600, color=ACCENT, font=SANS_ZH)
    add_multiline(s, 6.8, 4.5, 6, 2.5, [
        {'text': '1. 直线段：低剂量安全', 'size': 14, 'weight': 500, 'color': INK},
        {'text': '2. 曲线段：阈值附近', 'size': 14, 'weight': 500, 'color': INK},
        {'text': '3. 长尾段：超量风险陡增', 'size': 14, 'weight': 500, 'color': RED, 'bold': True},
        {'text': '', 'size': 6},
        {'text': '启示：', 'size': 14, 'weight': 600, 'color': ACCENT},
        {'text': '"安全的食品不是检测出来的，是生产出来的"', 'size': 14, 'weight': 500, 'color': INK, 'bold': True},
    ], line_spacing=1.4)


def slide_13_kzhong_practice(prs, current_page, total_pages):
    """P13 课中-练习 (任务驱动)"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 1, current_page, total_pages, title='课中 · 任务练习',
                subtitle='4 人小组合作 · 20 分钟限时')

    # 任务卡
    add_rect(s, 0.5, 1.9, 12.3, 1.5, fill=BLUE_LT, line=ACCENT, line_w=0.75)
    add_text(s, 0.8, 2.0, 11, 0.4, '任务：',
             size=16, weight=600, color=ACCENT, font=SANS_ZH)
    add_text(s, 0.8, 2.4, 11, 0.9,
             '为某火腿品牌设计 1 份营销方案，要求体现"3R 体系"思想：'
             '基本特征 (Root) + 作用原理 (Reaction) + 检测方案 (Regulation)。',
             size=14, weight=400, color=INK, font=SANS_ZH)

    # 三列小组任务
    add_text(s, 0.5, 3.6, 12, 0.4, '小组分工',
             size=18, weight=600, color=ACCENT, font=SANS_ZH)
    groups = [
        ('第 1 组', '产品定位', '梳理品牌核心卖点', RED),
        ('第 2 组', '客户画像', '识别 3 类目标客户', ACCENT),
        ('第 3 组', '传播策略', '选择 2 个传播渠道', GREEN),
        ('第 4 组', '风险预案', '设计 1 个危机应对', RED),
    ]
    x = 0.5
    for i, (g, t, d, c) in enumerate(groups):
        add_rect(s, x, 4.2, 2.95, 1.5, fill=PAPER, line=c, line_w=0.75)
        add_rect(s, x, 4.2, 2.95, 0.5, fill=c)
        add_text(s, x+0.2, 4.25, 2.75, 0.4, g,
                 size=14, weight=600, color=WHITE, font=SANS_ZH)
        add_text(s, x+0.2, 4.85, 2.75, 0.4, t,
                 size=16, weight=600, color=INK, font=SANS_ZH)
        add_text(s, x+0.2, 5.25, 2.75, 0.4, d,
                 size=12, weight=300, color=GREY_2, font=SANS_ZH)
        x += 3.15

    # 评价
    add_rect(s, 0.5, 5.95, 12.3, 0.7, fill=YEL_LT)
    add_text(s, 0.8, 6.05, 12, 0.5,
             '★ 评价标准：方案完整度 (40%) + 创新性 (30%) + 团队协作 (30%)',
             size=14, weight=500, color=INK, font=SANS_ZH)


def slide_14_kzhong_summary(prs, current_page, total_pages):
    """P14 课中-总结 (思维导图式)"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 1, current_page, total_pages, title='课中 · 知识回顾',
                subtitle='"3R 知识体系" 思维导图')

    # 中心节点
    cx, cy = W/2, 4.0
    add_rect(s, cx-1.2, cy-0.4, 2.4, 0.8, fill=ACCENT)
    add_text(s, cx-1.2, cy-0.4, 2.4, 0.8, '3R 体系',
             size=22, weight=600, color=WHITE, font=SANS_ZH,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

    # 3 个分支节点
    branches = [
        ('Root', '基本特征', '亚硝酸盐的\n理化性质', ACCENT, 1),
        ('Reaction', '作用原理', '护色 / 抑菌 / 风味\n致癌风险', RED, 2),
        ('Regulation', '检测方案', '1.0 准\n2.0 快\n3.0 又准又快\n4.0 智能', GREEN, 3),
    ]
    for label_en, label_zh, content, color, idx in branches:
        bx = 1.0 if idx == 1 else (5.5 if idx == 2 else 10.0)
        by = 1.9 if idx in (1, 3) else 4.8
        # 节点
        add_rect(s, bx, by, 2.5, 0.7, fill=color)
        add_text(s, bx, by, 2.5, 0.7, label_zh,
                 size=16, weight=600, color=WHITE, font=SANS_ZH,
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        # 英文标签
        add_text(s, bx, by+0.75, 2.5, 0.3, label_en,
                 size=10, weight=400, color=color, font=SANS,
                 align=PP_ALIGN.CENTER)
        # 详情
        add_text(s, bx-0.2, by+1.15, 2.9, 1.5, content,
                 size=12, weight=400, color=INK, font=SANS_ZH,
                 align=PP_ALIGN.CENTER, line_spacing=1.4)
        # 连接线 (手绘)
        d = s.shapes.add_connector(1, Inches(cx), Inches(cy), Inches(bx+1.25), Inches(by+0.35))
        d.line.color.rgb = color
        d.line.width = Pt(1.5)

    # 底部思政
    add_rect(s, 0.5, 6.7, 12.3, 0.4, fill=YEL_LT)
    add_text(s, 0.8, 6.75, 12, 0.3,
             '★ 学科理念：科学创新保障，食品风险可防可控',
             size=13, weight=500, color=RED, font=SANS_ZH)


def slide_15_khou(prs, current_page, total_pages):
    """P15 课后 (作业+拓展)"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 1, current_page, total_pages, title='课后 · 巩固拓展',
                subtitle='必做 + 选做 + 拓展阅读')

    # 三列
    cols = [
        ('必做作业', RED, [
            '完成 1 份 200 字营销方案',
            '提交至雨课堂',
            '截止：下节课前',
        ]),
        ('选做任务', ACCENT, [
            '录制 3 分钟讲解视频',
            '加入小组互评',
            '优秀作品班级展播',
        ]),
        ('拓展资源', GREEN, [
            '《食品科学》期刊论文',
            '中国食品科技学会网站',
            '扫码观看纪录片',
        ]),
    ]
    col_w = 4.0
    y = 2.0
    h = 4.5
    for i, (title, color, items) in enumerate(cols):
        x = 0.5 + i * (col_w + 0.15)
        add_rect(s, x, y, col_w, h, fill=PAPER, line=color, line_w=0.75)
        add_rect(s, x, y, col_w, 0.7, fill=color)
        add_text(s, x+0.3, y+0.15, col_w-0.6, 0.5, title,
                 size=18, weight=600, color=WHITE, font=SANS_ZH)
        item_y = y + 1.1
        for item in items:
            add_rect(s, x+0.3, item_y+0.18, 0.1, 0.1, fill=color)
            add_text(s, x+0.5, item_y, col_w-0.8, 0.4, item,
                     size=14, weight=400, color=INK, font=SANS_ZH)
            item_y += 0.55

    # 二维码占位
    add_rect(s, W-2.0, H-1.0, 1.4, 1.4, fill=WHITE, line=ACCENT, line_w=0.75)
    add_text(s, W-2.0, H-1.0, 1.4, 1.4, '扫码\n看视频',
             size=10, weight=400, color=ACCENT, font=SANS_ZH,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)


def slide_16_outcome_score(prs, current_page, total_pages):
    """P16 学习效果-成绩对比"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 2, current_page, total_pages, title='学习效果 · 成绩',
                subtitle='前测 vs 后测 · N=38')

    # 双柱状图 (前测/后测)
    # 手绘一个对比图
    w, h = 700, 360
    img = Image.new('RGB', (w, h), '#FAFAF8')
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 14)
        font_sm = ImageFont.truetype('/System/Library/Fonts/PingFang.ttc', 12)
    except:
        font = font_sm = ImageFont.load_default()

    categories = ['知识题', '案例分析', '方案设计', '现场答辩', '总分']
    pre  = [62, 55, 48, 50, 54]
    post = [85, 82, 78, 80, 81]

    pad_l, pad_r, pad_t, pad_b = 80, 40, 40, 60
    cw = (w - pad_l - pad_r) / len(categories)
    bar_w = cw * 0.32
    max_v = 100

    # 网格
    _P("line", d, [(pad_l, pad_t), (pad_l, h-pad_b)], fill='#7F8C8D', width=int(1))
    _P("line", d, [(pad_l, h-pad_b), (w-pad_r, h-pad_b)], fill='#7F8C8D', width=int(1))
    for i in range(1, 6):
        y = h - pad_b - (h - pad_t - pad_b) * i / 5
        _P("line", d, [(pad_l, y), (w-pad_r, y)], fill='#E0E0E0', width=int(0.5))
        d.text((5, y-8), f'{i*20}', fill='#7F8C8D', font=font_sm)

    for i, cat in enumerate(categories):
        cx = pad_l + cw * i
        # 前测 (红色)
        bh1 = (h - pad_t - pad_b) * pre[i] / max_v
        _P("rectangle", d, [cx+2, h-pad_b-bh1, cx+2+bar_w, h-pad_b], fill='#C8102E')
        d.text((cx+2, h-pad_b-bh1-22), f'{pre[i]}', fill='#C8102E', font=font)
        # 后测 (蓝色)
        bh2 = (h - pad_t - pad_b) * post[i] / max_v
        _P("rectangle", d, [cx+2+bar_w+4, h-pad_b-bh2, cx+2+bar_w*2+4, h-pad_b], fill='#002FA7')
        d.text((cx+2+bar_w+4, h-pad_b-bh2-22), f'{post[i]}', fill='#002FA7', font=font)
        # 类别
        d.text((cx, h-pad_b+10), cat, fill='#0A0A0A', font=font)

    d.text((20, 10), '前测 vs 后测 (满分 100)', fill='#0A0A0A', font=font)

    # 图例
    _P("rectangle", d, [w-180, 10, w-160, 30], fill='#C8102E')
    d.text((w-155, 12), '前测', fill='#0A0A0A', font=font)
    _P("rectangle", d, [w-100, 10, w-80, 30], fill='#002FA7')
    d.text((w-75, 12), '后测', fill='#0A0A0A', font=font)

    add_pic(s, img, 0.5, 2.0, w=7.0)

    # 右侧: 关键数据
    add_text(s, 8.0, 2.0, 5, 0.4, '关键数据',
             size=18, weight=600, color=ACCENT, font=SANS_ZH)
    add_multiline(s, 8.0, 2.6, 5, 4.5, [
        {'text': '平均分提升', 'size': 14, 'weight': 500, 'color': GREY_2},
        {'text': '54 → 81', 'size': 32, 'weight': 700, 'color': ACCENT},
        {'text': '+27 分', 'size': 18, 'weight': 600, 'color': GREEN},
        {'text': '', 'size': 8},
        {'text': '及格率', 'size': 14, 'weight': 500, 'color': GREY_2},
        {'text': '68% → 97%', 'size': 28, 'weight': 700, 'color': ACCENT},
        {'text': '+29 pp', 'size': 18, 'weight': 600, 'color': GREEN},
        {'text': '', 'size': 8},
        {'text': '优秀率', 'size': 14, 'weight': 500, 'color': GREY_2},
        {'text': '5% → 42%', 'size': 28, 'weight': 700, 'color': ACCENT},
        {'text': '+37 pp', 'size': 18, 'weight': 600, 'color': GREEN},
    ], line_spacing=1.2)


def slide_17_outcome_work(prs, current_page, total_pages):
    """P17 学习效果-作品"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 2, current_page, total_pages, title='学习效果 · 作品',
                subtitle='学生作品集 (已打码)')

    # 2x3 作品网格
    works = [
        ('作品 1', '品牌定位', '★★★★★'),
        ('作品 2', '客户画像', '★★★★☆'),
        ('作品 3', '传播方案', '★★★★★'),
        ('作品 4', '风险预案', '★★★★☆'),
        ('作品 5', '数据看板', '★★★★★'),
        ('作品 6', '答辩 PPT', '★★★★☆'),
    ]
    x, y = 0.5, 1.9
    w, h = 4.0, 2.4
    for i, (n, t, rating) in enumerate(works):
        cx = x + (i % 3) * (w + 0.15)
        cy = y + (i // 3) * (h + 0.2)
        # 卡片
        add_rect(s, cx, cy, w, h, fill=PAPER, line=ACCENT, line_w=0.5)
        # 图片占位
        add_rect(s, cx+0.2, cy+0.2, w-0.4, h-1.0, fill=BLUE_LT, line=ACCENT, line_w=0.5)
        add_text(s, cx+0.2, cy+0.2, w-0.4, h-1.0, '📷 作品图',
                 size=14, weight=400, color=GREY_2, font=SANS_ZH,
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        # 标题
        add_text(s, cx+0.2, cy+h-0.7, w-0.4, 0.3, n,
                 size=12, weight=600, color=ACCENT, font=SANS_ZH)
        add_text(s, cx+0.2, cy+h-0.4, w-0.4, 0.3, t,
                 size=14, weight=500, color=INK, font=SANS_ZH)
        add_text(s, cx+w-1.2, cy+h-0.4, 1.0, 0.3, rating,
                 size=12, weight=400, color=YELLOW, font=SANS_ZH,
                 align=PP_ALIGN.RIGHT)


def slide_18_outcome_cert(prs, current_page, total_pages):
    """P18 学习效果-证书"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 2, current_page, total_pages, title='学习效果 · 证书获奖',
                subtitle='2025-2026 学年')

    # 4 个大数字
    stats = [
        ('1+X 证书', '32 人', '通过率 84%', ACCENT),
        ('校级比赛', '8 项', '一等奖 3 项', RED),
        ('省级比赛', '2 项', '二等奖 1 项', GREEN),
        ('创新创业', '1 项', '校级立项', ACCENT),
    ]
    x = 0.5
    for label, val, sub, color in stats:
        add_rect(s, x, 2.0, 2.95, 2.5, fill=PAPER, line=color, line_w=0.75)
        add_rect(s, x, 2.0, 2.95, 0.5, fill=color)
        add_text(s, x+0.2, 2.05, 2.75, 0.4, label,
                 size=14, weight=600, color=WHITE, font=SANS_ZH)
        add_text(s, x+0.2, 2.7, 2.75, 1.0, val,
                 size=48, weight=600, color=color, font=SANS)
        add_text(s, x+0.2, 3.9, 2.75, 0.4, sub,
                 size=14, weight=400, color=GREY_2, font=SANS_ZH)
        x += 3.15

    # 证书墙
    add_text(s, 0.5, 4.8, 12, 0.4, '证书墙 (节选)',
             size=18, weight=600, color=ACCENT, font=SANS_ZH)
    add_rect(s, 0.5, 5.3, 12.3, 1.5, fill=BLUE_LT, line=ACCENT, line_w=0.5)
    add_text(s, 0.5, 5.3, 12.3, 1.5, '🏆  证书图片墙 (打码)\n学员姓名 / 地区已马赛克处理',
             size=14, weight=400, color=GREY_2, font=SANS_ZH,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)


def slide_19_highlight(prs, current_page, total_pages):
    """P19 特色亮点"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 3, current_page, total_pages, title='特色亮点',
                subtitle='创新举措 / 思政融入 / 跨学科')

    # 三大亮点
    highlights = [
        ('创新 1', '对接新业态', '引入 AI 营销工具 + 数据分析',
         '学生所学与企业所需高度匹配', ACCENT),
        ('创新 2', '"三阶六环"', '校企双元交替\n企业认知 → 校内学习 → 车间实战',
         '缩小育人目标与企业岗位需求差距', RED),
        ('创新 3', '课程思政', '大师工匠案例 + 传统文化智慧',
         '培养爱岗敬业、精益求精的工匠精神', GREEN),
    ]
    col_w = 4.0
    y = 2.0
    h = 4.5
    for i, (label, title, content, sub, color) in enumerate(highlights):
        x = 0.5 + i * (col_w + 0.15)
        add_rect(s, x, y, col_w, h, fill=PAPER, line=color, line_w=0.75)
        add_rect(s, x, y, col_w, 0.7, fill=color)
        add_text(s, x+0.3, y+0.15, col_w-0.6, 0.4, label,
                 size=14, weight=600, color=YELLOW, font=SANS_ZH)
        add_text(s, x+0.3, y+0.9, col_w-0.6, 0.5, title,
                 size=22, weight=600, color=INK, font=SANS_ZH)
        add_text(s, x+0.3, y+1.6, col_w-0.6, 1.5, content,
                 size=14, weight=400, color=INK, font=SANS_ZH, line_spacing=1.5)
        add_rect(s, x+0.3, y+3.5, col_w-0.6, 0.7, fill=YEL_LT)
        add_text(s, x+0.4, y+3.55, col_w-0.8, 0.6, sub,
                 size=12, weight=500, color=color, font=SANS_ZH,
                 anchor=MSO_ANCHOR.MIDDLE, line_spacing=1.3)


def slide_20_reflect_problem(prs, current_page, total_pages):
    """P20 反思-问题"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 4, current_page, total_pages, title='反思 · 存在问题',
                subtitle='聚焦教学中长期存在的 3 个问题')

    # 3 个问题卡
    problems = [
        ('问题 1', '虚拟仿真资源与企业实际项目不匹配',
         '现有 1.0 / 2.0 版本的仿真数据滞后于企业 3.0 智能产线',
         '学生掌握的"准"与"快"在实际应用中受限'),
        ('问题 2', '课前学习差异影响目标达成',
         '38 人中 3 人基础薄弱 (8%)，统一进度导致其掉队',
         '拓展学习难以全员参与'),
        ('问题 3', '思政融入的"自然度"需提升',
         '部分学生反馈思政案例"生硬"',
         '需要更贴合专业场景的隐性融入'),
    ]
    y = 2.0
    h = 1.5
    for i, (label, title, desc1, desc2) in enumerate(problems):
        add_rect(s, 0.5, y, 12.3, h, fill=PAPER, line=RED, line_w=0.75)
        add_rect(s, 0.5, y, 1.5, h, fill=RED)
        add_text(s, 0.5, y+0.2, 1.5, 0.4, label,
                 size=14, weight=600, color=WHITE, font=SANS_ZH,
                 align=PP_ALIGN.CENTER)
        add_text(s, 0.5, y+0.65, 1.5, 0.5, f'0{i+1}',
                 size=28, weight=200, color=WHITE, font=SANS,
                 align=PP_ALIGN.CENTER)
        add_text(s, 2.2, y+0.2, 10.5, 0.4, title,
                 size=16, weight=600, color=INK, font=SANS_ZH)
        add_text(s, 2.2, y+0.65, 10.5, 0.4, '· ' + desc1,
                 size=12, weight=400, color=GREY_1, font=SANS_ZH)
        add_text(s, 2.2, y+1.0, 10.5, 0.4, '· ' + desc2,
                 size=12, weight=400, color=GREY_1, font=SANS_ZH)
        y += h + 0.15


def slide_21_reflect_improve(prs, current_page, total_pages):
    """P21 反思-改进措施"""
    s = prs.slides.add_slide(prs.slide_layouts[6])
    setup_slide(s, 4, current_page, total_pages, title='改进措施',
                subtitle='问题 ↔ 措施 一一对应')

    # 3 个措施 (与 P20 镜像)
    measures = [
        ('措施 1', '校企共建仿真资源库',
         '联合本地 3 家食品企业，引入真实产线数据 (脱敏)',
         '每学期更新 30% 案例'),
        ('措施 2', '分层教学 + 智能辅导',
         '依托 AI 助教自动识别 3 类学生，匹配差异化任务',
         '基础生 5 人 + 中等生 25 人 + 拓展生 8 人'),
        ('措施 3', '专业场景思政素材库',
         '开发 20 个"专业 + 思政"双元素微案例',
         '将思政融入专业问题解决过程'),
    ]
    y = 2.0
    h = 1.5
    for i, (label, title, desc1, desc2) in enumerate(measures):
        add_rect(s, 0.5, y, 12.3, h, fill=PAPER, line=GREEN, line_w=0.75)
        add_rect(s, 0.5, y, 1.5, h, fill=GREEN)
        add_text(s, 0.5, y+0.2, 1.5, 0.4, label,
                 size=14, weight=600, color=WHITE, font=SANS_ZH,
                 align=PP_ALIGN.CENTER)
        add_text(s, 0.5, y+0.65, 1.5, 0.5, f'0{i+1}',
                 size=28, weight=200, color=WHITE, font=SANS,
                 align=PP_ALIGN.CENTER)
        add_text(s, 2.2, y+0.2, 10.5, 0.4, title,
                 size=16, weight=600, color=INK, font=SANS_ZH)
        add_text(s, 2.2, y+0.65, 10.5, 0.4, '· ' + desc1,
                 size=12, weight=400, color=GREY_1, font=SANS_ZH)
        add_text(s, 2.2, y+1.0, 10.5, 0.4, '· ' + desc2,
                 size=12, weight=400, color=GREY_1, font=SANS_ZH)
        y += h + 0.15

    # 收束: 致谢
    add_rect(s, 0.5, 6.8, 12.3, 0.4, fill=ACCENT)
    add_text(s, 0.5, 6.8, 12.3, 0.4,
             '感谢聆听 · 恳请指正',
             size=14, weight=500, color=WHITE, font=SANS_ZH,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)


# ============ 主流程 ============
def build_pptx(out_path='./teaching_比赛版_任务1.pptx'):
    prs = Presentation()
    prs.slide_width = Inches(W)
    prs.slide_height = Inches(H)

    # 5 大模块,21 个版式
    total = 21
    pn = 1
    # Module 1 (P1-P8)
    slide_01_cover(prs, '市场营销基础', '郑州轻工业大学', '陈开颖', signin_qr=True)
    pn += 1
    slide_02_toc(prs, total, pn); pn += 1
    slide_03_section_divider(prs, 0, total, pn); pn += 1
    slide_04_xueqing(prs, pn, total); pn += 1
    slide_05_objectives(prs, pn, total); pn += 1
    slide_06_keypoints(prs, pn, total); pn += 1
    slide_07_strategy(prs, pn, total); pn += 1
    slide_08_evaluation(prs, pn, total); pn += 1
    # Module 2 (P9-P15)
    slide_03_section_divider(prs, 1, total, pn); pn += 1
    slide_09_flowchart(prs, pn, total); pn += 1
    slide_10_kqian(prs, pn, total); pn += 1
    slide_11_kzhong_intro(prs, pn, total); pn += 1
    slide_12_kzhong_explain(prs, pn, total); pn += 1
    slide_13_kzhong_practice(prs, pn, total); pn += 1
    slide_14_kzhong_summary(prs, pn, total); pn += 1
    slide_15_khou(prs, pn, total); pn += 1
    # Module 3 (P16-P18)
    slide_03_section_divider(prs, 2, total, pn); pn += 1
    slide_16_outcome_score(prs, pn, total); pn += 1
    slide_17_outcome_work(prs, pn, total); pn += 1
    slide_18_outcome_cert(prs, pn, total); pn += 1
    # Module 4 (P19)
    slide_03_section_divider(prs, 3, total, pn); pn += 1
    slide_19_highlight(prs, pn, total); pn += 1
    # Module 5 (P20-P21)
    slide_03_section_divider(prs, 4, total, pn); pn += 1
    slide_20_reflect_problem(prs, pn, total); pn += 1
    slide_21_reflect_improve(prs, pn, total); pn += 1

    prs.save(out_path)
    print(f'✓ 已生成: {out_path}')
    print(f'  页数: {len(prs.slides)}')
    print(f'  画布: {W}" x {H}" (16:9)')
    print(f'  配色: IKB ({ACCENT[0]:02X}{ACCENT[1]:02X}{ACCENT[2]:02X}) · 朱红 ({RED[0]:02X}{RED[1]:02X}{RED[2]:02X}) · 麦黄 ({YELLOW[0]:02X}{YELLOW[1]:02X}{YELLOW[2]:02X})')
    print(f'  字体: Helvetica Neue / PingFang SC')


if __name__ == '__main__':
    out = os.path.join(os.path.dirname(__file__), 'teaching_比赛版_任务1.pptx')
    build_pptx(out)
