# Comparison And Scaling

Use this card for comparative design, periodization shifts, level-of-analysis changes, and stuck projects.

## Core Idea

Many stalled projects revive when the comparison changes or when the scale shifts. A weak question often becomes stronger by deciding whether the argument is about actors, institutions, genres, networks, events, periods, or structures.

## Reframing Moves

- Compare across regions, institutions, genres, or moments to reveal what was assumed universal.
- Shift from event to process, or from process to conjuncture.
- Shift from elite discourse to everyday practice, or the reverse.
- Move from nation-scale to transregional circulation, or the reverse.
- Replace a before/after story with a continuity/rupture test.

## Output Format

```markdown
**Current frame:** ...
**Alternative frame:** ...
**What new tension appears:** ...
**What evidence burden changes:** ...
**Whether to adopt:** yes / no / maybe
```

## Red Flags

- Comparison is added only to sound bigger.
- Scaling creates more material than the user can handle.
- The new frame does not sharpen the problem.
