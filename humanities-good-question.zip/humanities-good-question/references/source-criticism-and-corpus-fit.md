# Source Criticism And Corpus Fit

Use this card when the user has archives, interviews, texts, platforms, media, ethnography, survey data, or digital corpora but has not matched them to a question yet.

## Core Idea

Good humanities and social-science questions respect what the material can and cannot bear. A source base is not just raw input; it shapes the scale, claims, and limits of the project.

## Matching Questions To Materials

- Archive-heavy materials support reconstruction, institutional process, category formation, and contested interpretation, but often underrepresent subaltern voices.
- Interviews and ethnography support meaning-making, practice, and lived experience, but usually require sharper scope and reflexive limits.
- Large textual or digital corpora support pattern discovery and discourse shifts, but need close-reading checks and careful construct validity.
- Administrative or survey data support distributional and comparative claims, but often flatten context and categories.

## Output Format

```markdown
**Source base:** ...
**Best-fit question types:** ...
**What this material can show well:** ...
**What it cannot show well:** ...
**Claim ceiling:** ...
**Best repair if mismatch exists:** ...
```

## Red Flags

- The user's favorite source cannot answer the stated question.
- The material is treated as transparent rather than produced and situated.
- The project assumes evidence of discourse equals evidence of practice.
