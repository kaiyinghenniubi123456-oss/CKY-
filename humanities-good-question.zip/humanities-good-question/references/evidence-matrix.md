# Evidence Matrix

Use this card when the agent needs to test whether a candidate question matches the available material and challenge standard.

## Core Idea

Different question types require different evidence paths. The aim is not laboratory falsification in all cases, but an honest standard for what could support, complicate, or seriously weaken the proposed interpretation.

## Matrix

| Question type | Typical evidence path | Strong challenge standard |
|---|---|---|
| Historiographical revision | field-defining texts plus new archive or rereading | key source base does not support the claimed revision |
| Concept clarification | competing definitions, usage contexts, and case evidence | distinctions collapse in actual usage |
| Causal or process explanation | comparative cases, process tracing, or sequence evidence | rival explanation fits the evidence as well or better |
| Discourse or representation | corpus pattern plus close reading and context | language pattern does not track the claimed social meaning |
| Institutional analysis | rules, memos, organizational records, and actor accounts | formal rules and actual practice do not align with the claim |
| Ethnographic or interview-based interpretation | situated accounts, field context, and reflexive limits | account cannot travel beyond a narrow anecdote |

## Output Format

```markdown
**Candidate:** ...
**Question type:** ...
**Best evidence path:** ...
**Challenge standard:** ...
**Feasibility with current materials:** high / medium / low
**Repair if weak:** ...
```

## Red Flags

- The evidence path is really just "read more."
- The challenge standard is impossible to state.
- The project claims more than the material can carry.
