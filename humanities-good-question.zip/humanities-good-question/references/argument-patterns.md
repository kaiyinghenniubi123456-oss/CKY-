# Argument Patterns

Use this card when the user has a lot of notes or material but no claim shape.

## Core Idea

Questions improve when they imply an argument form. A project should know whether it is revising a chronology, qualifying a theory, explaining variation, reconstructing a mechanism, or exposing a category's instability.

## Common Patterns

- Revisionist: the accepted story is incomplete or misleading because ...
- Boundary-condition: the standard claim holds only when ...
- Mechanism: the outcome happened through ... rather than ...
- Translation: a concept from field A reveals a blind spot in field B because ...
- Reclassification: materials treated as X are better understood as Y.
- Scale-shift: the phenomenon looks different when moved from local to transregional, or from event to institution.

## Output Format

```markdown
**Candidate question:** ...
**Best argument pattern:** ...
**Main rival reading:** ...
**Evidence needed to distinguish them:** ...
```

## Red Flags

- The project has findings but no argumentative through-line.
- Rivals are straw men.
- The argument pattern requires evidence the user does not have.
