# Question Strengthening Patterns For Humanities And Social Science

Use this card after raw candidate generation, especially when the output still sounds like a topic, gap, method, corpus, or chapter activity rather than a research question.

## Core Idea

Most weak questions are not yet questions. They are themes, objects, literatures, methods, or ambitions. Convert them into questions by naming the uncertainty, the stake, the literature position, the likely counterreading, and the evidence that could change judgment.

## Rewrite Patterns

| Weak form | Stronger form |
|---|---|
| "Study X in period Y" | "How does X in period Y force us to revise a larger understanding of Z?" |
| "Analyze discourse on X" | "What does discourse on X reveal about the formation, contestation, or limits of category Y?" |
| "Use theory T to read corpus C" | "What prediction or blind spot does T reveal in corpus C that rival framings would miss?" |
| "No one has examined case C" | "What accepted claim becomes unstable if case C behaves differently?" |
| "Compare A and B" | "Which difference between A and B matters for explaining outcome C?" |
| "Explore platform/data trend D" | "What institutional, conceptual, or behavioral change does trend D indicate, and what alternative reading competes with it?" |
| "Discuss archive/source S" | "What question can source S answer unusually well, and what common claim could it challenge?" |

## Strengthening Procedure

1. Label the weak form: topic, gap, method, corpus, comparison, concept, or chronology.
2. Name the missing stake: interpretation, theory, historiography, explanation, policy, or public understanding.
3. Add a rival: an alternative reading, category, periodization, or causal story.
4. Add a challenge standard: what source or finding would seriously weaken the preferred reading?
5. Shrink scope until a short pilot memo could update judgment.

## Output Format

```markdown
**Before:** ...
**Weak form:** topic / gap / method / corpus / comparison / concept / chronology
**After:** ...
**What changed:** ...
**Challenge standard:** ...
```

## Red Flags

- The rewrite only becomes longer.
- The new question still depends on a favored theory label more than a real puzzle.
- No plausible answer would change what the user writes next.
