# Field Map Before Ideation

Use this card when the user requests current scholarship, historiography, source-grounded customization, recent debates, or target-journal fit.

## Core Idea

Do not generate questions from generic taste when field structure matters. First build a compact field map that shows major camps, overused assumptions, evidentiary bottlenecks, and seams where a project can intervene.

## Evidence Plan

Gather only enough evidence to make better question choices:

1. Define the discipline, subfield, geography, period, and output type.
2. Search for 6-12 high-signal sources: review essays, handbook chapters, editorials, major monographs, state-of-the-field articles, society pages, or target-journal statements.
3. Prefer primary or official sources over tertiary summaries; for historical fields, prefer field-defining books and review essays; for social science, prefer major review articles and methods debates.
4. Extract camps, recurrent puzzles, overloaded concepts, source bottlenecks, and explicit future-work claims.
5. Stop when new sources repeat the same fault lines or when the user's time budget is reached.

## Field Map Format

```markdown
## Field Map

**Scope:** ...
**Source base:** 6-12 sources, with links or citations
**Major camps or schools:** ...
**What the field already agrees on:** ...
**Live disagreements:** ...
**Overloaded concepts:** ...
**Source or data bottlenecks:** ...
**What changed recently:** ...
**Reviewer or committee expectations:** ...
**Question opportunities:** ...
**Evidence gaps in this map:** ...
```

## Conversion To Questions

After the map:

1. Generate candidate questions only from tensions supported by the map.
2. Mark each candidate as grounded, inferred, or speculative.
3. Pair speculative candidates with the evidence needed before commitment.
4. Feed the strongest candidates into `question-patterns.md`, then `reviewer-gate.md`.

## Red Flags

- The map becomes a mini literature review instead of a decision aid.
- Sources are listed but not converted into tensions or openings.
- The proposed question merely follows fashion.
