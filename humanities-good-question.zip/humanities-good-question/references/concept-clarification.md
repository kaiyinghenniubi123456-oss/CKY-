# Concept Clarification

Use this card when the key term is attractive but vague: modernity, identity, ritual, memory, governance, platform, empire, gender, community, resilience, discourse, and similar concepts.

## Core Idea

Many weak questions fail because the main concept shifts meaning across authors, periods, scales, or actors. The project improves when the concept is bounded, historicized, and tied to observable evidence.

## Clarification Procedure

1. Name the concept.
2. List at least two competing meanings in the literature or common usage.
3. State which meaning the project adopts, revises, or rejects.
4. Define the unit and scale where the concept operates.
5. Identify what sources could show the concept in practice rather than only in theory.

## Output Format

```markdown
**Concept:** ...
**Competing meanings:** ...
**Working definition:** ...
**Boundary:** ...
**What evidence would test this use:** ...
```

## Red Flags

- The same concept names cause, effect, and context at once.
- The concept is treated as timeless.
- No evidence could distinguish one meaning from another.
