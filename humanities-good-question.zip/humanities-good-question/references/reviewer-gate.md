# Reviewer Gate

Use this card near the end of the workflow to pressure-test the strongest questions before presenting them as mature candidates.

## Core Idea

Before a question becomes a recommendation, make the strongest committee, reviewer, editor, or advisor objection against it. A mature humanities or social-science question should survive a skeptical reader who asks why this matters, who cares, where it sits in the literature, and whether the material can really bear the claim.

## Desk-Reject Checks

Reject, rewrite, or park a candidate if it has any fatal flaw:

1. **No stake:** It changes no larger understanding, debate, or decision.
2. **Gap-only:** The main argument is that the case is under-studied.
3. **Concept fog:** The core terms remain elastic or undefined.
4. **Theory-first:** A framework appears before the problem is clear.
5. **No literature position:** The audience cannot tell which conversation it enters.
6. **No challenge standard:** No realistic evidence could weaken or qualify the claim.
7. **No feasible entry:** A credible pilot cannot start with the available materials and time.
8. **No downside learning:** A negative result would produce only disappointment, not a useful reframing.
9. **Wrong scale:** The question asks for a book when the user has sources for a paper, or vice versa.

## Output Format

```markdown
## Reviewer Gate

**Candidate:** ...
**Likely rejection:** ...
**Fatal?** yes / no / uncertain
**Repair:** ...
**Decision:** advance / rewrite / park / discard
```

## Repair Moves

- Replace a gap with a stake.
- Narrow the concept or period.
- Change the unit of analysis.
- Add a rival interpretation.
- Lower the claim ceiling to fit the materials.
- Turn the project into a pilot memo, annotated bibliography, or question map first.

## Red Flags

- Every candidate is treated as viable.
- Objections are generic rather than candidate-specific.
- Repair moves make the project larger rather than sharper.
