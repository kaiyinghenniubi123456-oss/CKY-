# Literature Positioning

Use this card when the user has material or a hunch but cannot say where the intervention sits.

## Core Idea

A strong question enters a live conversation. It does not just add another case; it says which debate, category, chronology, explanation, or canon it repositions.

## Positioning Moves

- Debate move: join an explicit dispute and state what your evidence changes.
- Revision move: show that a standard chronology, category, or causal chain needs revision.
- Clarification move: untangle a concept that different authors use inconsistently.
- Scaling move: show that the same phenomenon looks different at another unit or scope.
- Translation move: bring a framing from one field into another where it reveals a blind spot.
- Archive move: show how a new corpus or overlooked source base changes what can be argued.

## Output Format

```markdown
**Closest debate:** ...
**Dominant reading:** ...
**Your intervention:** ...
**Why this is not just a gap-fill:** ...
**Who might resist it:** ...
```

## Red Flags

- The user cannot name any literature audience.
- The intervention is "adding a case study" with no conceptual payoff.
- The project talks about novelty but not leverage.
