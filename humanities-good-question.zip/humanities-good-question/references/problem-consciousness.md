# Problem Consciousness

Use this card when the user has a broad theme but no real problem yet.

## Core Idea

A humanities or social-science project becomes strong when it names not just a subject but the larger understanding at stake. A case matters because it destabilizes a settled narrative, clarifies a concept, revises a chronology, redraws a causal story, or changes what counts as evidence.

## Questions To Ask

- What established understanding would remain too simple if this project succeeds?
- Which audience should care: historians of a period, theorists of a concept, area scholars, policy scholars, sociologists of an institution, literary critics of a genre?
- Is the stake interpretive, explanatory, methodological, historiographical, ethical, or political?
- What has the current literature normalized, backgrounded, or mislabeled?
- What would become newly visible if the user's case were taken seriously?

## Output Format

```markdown
**Surface topic:** ...
**Underlying problem:** ...
**Who should care:** ...
**What understanding could change:** ...
**Most promising intervention type:** interpretation / concept / historiography / explanation / method / source base
```

## Red Flags

- The project is only about a place, person, text, or event.
- The stake is only personal enthusiasm.
- The problem statement is really a chapter summary.
