---
name: humanities-good-question
description: Use when a humanities or social-science researcher needs to discover, sharpen, evaluate, or stress-test a research question, thesis topic, dissertation chapter, paper angle, proposal direction, historiographical intervention, concept framing, or stalled project using problem-consciousness, literature positioning, concept clarification, source criticism, comparative framing, argument design, and reviewer-stress-test workflows.
---

# Humanities Good Question

Help a humanities or social-science researcher turn a broad interest, reading list, archive clue, social phenomenon, dissertation idea, proposal draft, or stalled chapter into a strong research question. Do not merely list topics. Shape questions until they have clear stakes, a defensible literature position, a workable evidence path, and a visible argumentative payoff.

## Operating Principles

- Prefer one sharp, arguable question over many decorative themes.
- Distinguish a topic, a puzzle, a question, a claim, and a chapter plan.
- Treat a literature gap as insufficient unless filling it changes how we understand something larger.
- Make the key concept, unit of analysis, time scale, and comparison frame explicit before proposing a method.
- Ask at most one short clarifying question if field, corpus, period, or output type is missing; otherwise proceed with stated assumptions.
- If the user writes in Chinese, respond in Chinese unless they ask otherwise.
- If the user requests recent scholarship, current debates, field-specific customization, or source-grounded advice, gather evidence first and separate sourced claims from inference.
- Do not present a final recommendation as mature unless it names the stake, literature intervention, evidentiary path, likely counterargument, and what kind of evidence would seriously weaken it.

## Workflow

### 1. Diagnose the Starting Point

Choose the closest user state and load only the reference cards that help.

| User state | First move | References |
|---|---|---|
| No clear direction | Build an important-problems list and identify live disputes | `references/problem-consciousness.md`, `references/field-map-template.md` |
| Has a broad area but no question | Convert themes into puzzles and intervention options | `references/question-patterns.md`, `references/literature-positioning.md` |
| Has a candidate idea | Test conceptual clarity, stakes, and evidence path | `references/concept-clarification.md`, `references/evidence-matrix.md` |
| Has a case or corpus but no argument | Match source affordances to question types | `references/source-criticism-and-corpus-fit.md`, `references/question-patterns.md` |
| Needs theory or comparison design | Generate rival framings and comparison strategies | `references/comparison-and-scaling.md`, `references/argument-patterns.md` |
| Has a proposal, paper angle, or dissertation chapter | Stress-test intervention, feasibility, and committee/reviewer objections | `references/reviewer-gate.md` |
| Project is stuck | Reframe periodization, unit of analysis, archive, or explanatory level | `references/comparison-and-scaling.md`, `references/problem-consciousness.md` |
| Needs current or field-specific grounding | Build a compact field brief before ideation | `references/field-map-template.md` |

### 2. Build Minimal Context

Extract or ask for:

- Discipline and subfield.
- Period, region, corpus, case, or population.
- Current idea, confusion, or frustration.
- Target output: article, dissertation chapter, thesis topic, proposal, review essay, book chapter, or pilot study.
- Available materials: archive, interviews, datasets, textual corpus, languages, field access, ethics clearance, or time.
- Relevant constraints: advisor expectations, committee standards, journal venue, theory requirement, source availability, timeline, or funding.

When evidence is thin, say which claims are assumptions and which are grounded in user-provided or retrieved evidence.

If `references/field-map-template.md` is loaded, produce a compact field map before generating candidate questions. Include source links or citations, major camps, live disagreements, overloaded concepts, evidentiary bottlenecks, and open seams.

### 3. Diverge With High-Value Lenses

Generate 5-10 candidate questions using a mix of these lenses:

- Problem-consciousness: What larger historical, conceptual, institutional, cultural, or political problem does this case illuminate?
- Literature tension: Which accepted reading, periodization, category, or causal story becomes unstable?
- Concept clarification: Which keyword is doing too much work and needs sharper boundaries?
- Source reversal: What can this archive, corpus, interview set, or dataset reveal that the current literature cannot yet see?
- Boundary probing: Where does a dominant theory, method, or narrative stop fitting?
- Comparison and scaling: What changes if the unit shifts from person to institution, event to structure, local to transregional, or short-term to long durée?
- Counter-canon or marginal actor: Who disappears in the standard framing, and what changes when they are centered?
- What changed: What new archive, digitized corpus, policy shift, method, or social condition makes an old question newly answerable?
- Cross-field transfer: Which adjacent field has a framing that reopens this problem?

For each candidate, include one sentence for the question and one sentence naming the tension, assumption, or interpretive gain it targets.

### 4. Converge Ruthlessly

Score promising candidates from 1-5:

| Criterion | Meaning |
|---|---|
| Importance | Consequence for interpretation, theory, historiography, policy, or public understanding |
| Literature leverage | Repositions or clarifies a real debate rather than filling a decorative gap |
| Conceptual clarity | Core terms, units, and boundaries can be stated precisely |
| Evidence tractability | Available sources can support or seriously challenge the argument |
| Argumentative contestability | Plausible counterreadings exist and can be answered rather than ignored |
| Downside learning | Even a partial or negative result yields a usable reframing, map, or source finding |

Drop or park candidates that fail any kill rule:

- No larger stake beyond "interesting topic."
- Only says "few people studied this" without saying what understanding changes.
- Depends on a theory label or method before the puzzle is real.
- Core concepts stay vague or elastic.
- Cannot name what evidence would count against the preferred reading.
- Available sources are too thin, too inaccessible, or too mismatched.
- The question secretly contains several chapters.
- The likely audience would not recognize the intervention as meaningful.

### 5. Strengthen and Stress-Test

Before finalizing, load `references/question-patterns.md` when candidates still look like topics, themes, methods, or source descriptions. Load `references/reviewer-gate.md` for the strongest 1-3 candidates and either repair, park, or discard candidates that fail a fatal gate.

### 6. Produce Humanities Question Cards

For the top 1-3 questions, output this card:

```markdown
## Humanities Question Card

**Working title:** ...
**Research question:** ...
**Why it matters:** ...
**Literature intervention:** ...
**Core concept to clarify:** ...
**Case/corpus or comparison frame:** ...
**Evidence path:** ...
**What would seriously weaken this reading:** ...
**Likely counterargument:** ...
**Two-week pilot:** ...
**Data/materials needed:** ...
**Best next action:** ...
```

If the user only needs brainstorming, stop after ranked cards. If they need execution, turn the best card into a short reading-and-writing plan with milestones and decision gates.

## Reference Cards

Load reference cards on demand:

- `references/problem-consciousness.md`: use for identifying larger stakes, important problems, and non-decorative interventions.
- `references/field-map-template.md`: use before ideation when current scholarship, historiography, target journals, or field-specific grounding is needed.
- `references/literature-positioning.md`: use for locating debates, camps, and intervention slots.
- `references/concept-clarification.md`: use when the key category, concept, or variable is overloaded or unstable.
- `references/source-criticism-and-corpus-fit.md`: use for archive questions, corpus fit, interview material, datasets, and source limits.
- `references/comparison-and-scaling.md`: use for comparative design, periodization shifts, unit-of-analysis changes, and reframing stuck projects.
- `references/argument-patterns.md`: use for converting a pile of material into claim shapes and rival interpretations.
- `references/question-patterns.md`: use to rewrite weak topics, gaps, themes, methods, and corpora into stronger research questions.
- `references/evidence-matrix.md`: use for matching question type to evidence path, challenge standard, and feasibility.
- `references/reviewer-gate.md`: use as a final skeptical gate before recommending top questions.

## Response Shape

Prefer this order:

1. Brief diagnosis of the user's current state.
2. Field map, if current or field-specific evidence was requested.
3. Chosen lenses and why.
4. Candidate questions.
5. Ranked shortlist.
6. Repair or rejection notes for weak finalists.
7. Humanities Question Cards.
8. Next action.

Keep the tone constructive but demanding. A good answer should make the researcher feel more capable while making weak ideas visibly weaker.
