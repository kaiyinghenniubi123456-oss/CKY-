# Chain Map

Use this card when the user provides a full proposal draft and wants to know whether it hangs together.

## Core Idea

A strong proposal is a chain of reasons, not a pile of sections. Review it by reconstructing the hidden sentence that connects title, question, basis, value, content, method, feasibility, and outcome.

Another way to see the same chain is: pain point -> bottleneck -> solution -> key point -> hard point -> method -> support conditions -> advance over prior work.

## Chain Questions

Ask these in order:

1. What is the exact object and problem?
2. Why is this problem worth solving now?
3. What is still unresolved in current research or practice?
4. What does this proposal claim it will clarify, explain, or establish?
5. Which research tasks are necessary to get there?
6. What evidence path supports each task?
7. Why is the plan proportionate to the applicant's resources?
8. What output is realistic if the chain holds?

## Output Format

```markdown
**Title:** ...
**Core question:** ...
**Why now:** ...
**Research gap or instability:** ...
**Intervention:** ...
**Content path:** ...
**Evidence path:** ...
**Feasibility basis:** ...
**Expected outcome:** ...
**Chain verdict:** smooth / jumpy / broken
```

## Red Flags

- The title names a topic, but the text studies something narrower or different.
- The proposal has many good points, but they do not form a single line.
- The expected outcome sounds larger than the evidence path can support.
