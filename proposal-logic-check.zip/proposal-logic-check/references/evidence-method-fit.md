# Evidence Method Fit

Use this card when research content looks concrete but the evidence path is weak, generic, or disconnected.

## Core Idea

A proposal becomes believable when each task has a matching evidence path. Methods should support content, not float as abstract labels.

## Matching Questions

- For each content task, what material, dataset, archive, corpus, interview set, or comparison supports it?
- Does the method explain how claims will be established, not just which discipline labels are used?
- Can the source base support causal, interpretive, descriptive, or comparative claims at the level promised?
- Are there any tasks whose evidence path is missing or obviously weak?

## Output Format

```markdown
**Research task:** ...
**Claim type:** descriptive / interpretive / explanatory / comparative
**Evidence path:** ...
**Method fit:** strong / partial / weak
**What is missing:** ...
```

## Red Flags

- "Interdisciplinary" replaces methodological explanation.
- Methods are listed once, but never tied to specific tasks.
- The material can show presence, but the proposal claims mechanism or broad causation.
