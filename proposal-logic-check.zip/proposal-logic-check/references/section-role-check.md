# Section Role Check

Use this card when the proposal feels scattered, repetitive, or bloated.

## Core Idea

Many proposal logic problems come from sections doing the wrong job. A literature review starts arguing innovation, research content starts repeating value, and innovation restates topic importance.

## Section Roles

- Title: define the object and angle without pretending to do everything.
- Question or problem: state what is not yet understood and why that matters.
- Literature basis: create pressure for the question, not merely show reading volume.
- Research value: explain what understanding, policy, method, or field map changes.
- Research content: break the question into answerable tasks.
- Methods and materials: explain how each task will be supported.
- Innovation: state what is new compared with existing work and why it is earned.
- Feasibility: show why the project can actually be done.
- Outcomes: stay proportionate to scope and timeframe.

## Bottleneck Reading

When the proposal uses conventional headings, read them through this practical logic:

- Basis or justification: "sell" the pain point and establish present significance.
- Research status: find the real bottleneck, not just summarize prior work.
- Research content: propose the solution to that bottleneck.
- Research focus: isolate the most critical part of the solution.
- Research difficulty: locate the hardest part inside the focus.
- Methods: match a method to the bottleneck rather than naming disciplines in the abstract.
- Feasibility: prove that current conditions can support the solution path.
- Innovation: state how this solution advances beyond previous ones.
- Research foundation: show the applicant has done adjacent work before.
- References: reveal what scholarly standard and frontier the proposal aligns with.

This framing is especially useful when the user asks whether the proposal is "顺不顺" or "有没有一条线".

## Output Format

```markdown
**Section:** ...
**Intended role:** ...
**What it is actually doing:** ...
**Problem type:** missing / repetitive / misassigned / inflated
**Best fix:** ...
```

## Red Flags

- The same sentence could appear in three different sections.
- The proposal sounds full but every section repeats "important, innovative, valuable."
- The real research question is hidden inside content or innovation.
