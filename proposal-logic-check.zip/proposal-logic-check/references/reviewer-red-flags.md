# Reviewer Red Flags

Use this card near the end to simulate a skeptical reviewer reading quickly for logic breaks.

## Core Idea

Reviewers often decide from structure before details. If they cannot see a clean line from problem to content to method to outcome, trust drops fast.

## Fast Reject Signals

1. The title and the actual problem do not match.
2. The proposal has a grand theme but no sharp question.
3. The literature review does not generate a concrete research need.
4. The value section relies on slogans more than argument.
5. The research content is a list of materials or chapters, not a path to an answer.
6. The methods are named but not operationalized.
7. Innovation is declared, not demonstrated.
8. Feasibility and outcomes are out of scale.
9. The whole draft cannot be summarized as one believable sentence.

## Output Format

```markdown
## Reviewer Gate

**Likely first doubt:** ...
**Where trust drops:** ...
**Severity:** fatal / major / minor
**Best repair before submission:** ...
```

## Red Flags

- The review sounds polite but does not identify where the chain breaks.
- Too many suggestions bury the one issue that actually matters.
- The diagnosis focuses on wording while ignoring structure.
