# Innovation Feasibility Outcomes

Use this card when the end of the proposal sounds polished but unconvincing.

## Core Idea

Innovation, feasibility, and outcomes are the credibility test at the end of the chain. If they are inflated, generic, or detached from the core design, reviewers stop trusting the whole proposal.

## Checks

- Is innovation specific to this project, or could any proposal say the same thing?
- Does the innovation emerge from source type, framework, comparison, data construction, or question design?
- Is feasibility supported by prior work, source access, team conditions, or a realistic schedule?
- Do the outcomes fit the project's scale and time horizon?

## Output Format

```markdown
**Claimed innovation:** ...
**Is it earned?** yes / partly / no
**Feasibility basis:** ...
**Outcome realism:** high / medium / low
**Best repair:** ...
```

## Red Flags

- Innovation repeats importance using different words.
- Feasibility rests only on enthusiasm.
- A short project promises oversized outputs.
