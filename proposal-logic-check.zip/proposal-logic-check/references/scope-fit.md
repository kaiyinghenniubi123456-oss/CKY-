# Scope Fit

Use this card when the topic feels too large, too ambitious, or split across too many tasks.

## Core Idea

A common proposal failure is hidden scale inflation. The title, content, and outcomes quietly contain several projects, several methods, or several books.

## Checks

- Is the title broader than the actual materials can support?
- Does the proposal contain more than one main question?
- Are the research content sections parallel parts of one answer, or separate subprojects?
- Does the schedule match the amount of material, comparison, and output promised?
- Could the same project be explained more clearly at a smaller scale?

## Output Format

```markdown
**Current scope:** ...
**Where it expands too far:** ...
**Effect on logic:** ...
**Scope verdict:** proportionate / stretched / overloaded
**Best narrowing move:** ...
```

## Red Flags

- The project wants to prove a civilization-scale claim from one source type.
- Each chapter could be a standalone funded project.
- The title promises more than the content or method can deliver.
