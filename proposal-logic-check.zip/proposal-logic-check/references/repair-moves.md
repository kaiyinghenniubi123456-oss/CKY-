# Repair Moves

Use this card when the user wants revision help after diagnosis.

## Core Idea

Repair the logic chain with the smallest structural edits first. Do not start by rewriting every sentence.

## Common Moves

- Narrow the title until it matches the real question.
- Rewrite the last paragraph of the literature review so it produces one concrete unresolved issue.
- Turn research content headings into answer steps rather than material piles.
- Attach one evidence path to each content task.
- Move generic "innovation" language into the section where it is actually earned.
- Cut outcomes that exceed the stated schedule or source base.

## Output Format

```markdown
**Problem:** ...
**Repair move:** ...
**Where to revise:** title / basis / value / content / method / innovation / feasibility / outcomes
**Expected gain:** ...
```

## Red Flags

- Revisions make the proposal longer but not clearer.
- Repair moves add new claims instead of sharpening existing ones.
- The core question still cannot be stated in one sentence after revision.
