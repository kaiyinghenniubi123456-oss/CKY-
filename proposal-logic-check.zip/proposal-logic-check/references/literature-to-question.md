# Literature To Question

Use this card when the literature review is long but the proposal still lacks a sharp research question.

## Core Idea

The job of a literature review in a proposal is not to prove diligence. It is to create a specific unresolved problem that justifies the project.

## Tests

- Does the review end in a concrete unresolved issue?
- Is the proposal fixing a real instability, contradiction, blind spot, or evidence gap?
- Does the question grow out of the literature, or is it parachuted in afterward?
- Is the stated value academic, or only framed through broad policy language?

## Rewrite Moves

- Replace "existing research is insufficient" with exactly what remains unclear.
- Replace "few studies have focused on..." with what interpretive or explanatory consequence that absence creates.
- Replace a long chronology of prior scholarship with 2-4 live tensions.

## Output Format

```markdown
**Literature endpoint:** ...
**Real unresolved issue:** ...
**Does it produce the proposal question?** yes / partly / no
**Main problem:** ...
**Best repair:** ...
```

## Red Flags

- The review proves the field is broad, but not why this project is necessary.
- The final question could be removed without changing the literature review.
- Policy language substitutes for academic pressure.
