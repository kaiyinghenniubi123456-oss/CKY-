---
name: proposal-logic-check
description: Use when a user needs to review, stress-test, or revise the logic of a grant proposal, project application, thesis proposal, or research plan by checking whether the title, problem, literature basis, value, research content, methods, innovation, feasibility, and expected outcomes form a coherent argument chain rather than a pile of sections.
---

# Proposal Logic Check

Help the user test whether a proposal reads as one continuous argument. Do not merely polish wording. Check whether each section answers the right question, supports the next section, and stays consistent with the title and core problem.

## Operating Principles

- Treat the proposal as a logic chain, not a list of required headings.
- Prefer finding root-level logic breaks over surface phrasing issues.
- Separate topic size, research question, research content, method, innovation, and expected output.
- Flag when a section sounds good alone but does not support the proposal's main claim.
- Ask at most one short clarifying question if the proposal text or section order is missing; otherwise proceed with stated assumptions.
- If the proposal is in Chinese, respond in Chinese unless asked otherwise.
- When evidence is thin, distinguish direct textual evidence from your inference.
- Do not rewrite the whole proposal unless the user asks; first diagnose the logic.

## Workflow

### 1. Identify The Proposal Skeleton

Extract the proposal's visible chain:

1. Title
2. Core problem or research question
3. Academic basis or literature review
4. Research value
5. Research content
6. Methods or evidence path
7. Innovation
8. Feasibility and schedule
9. Expected outcomes

If the proposal uses different headings, map them onto this chain before evaluating.

### 2. Diagnose The User State

Choose the closest state and load only the needed reference cards.

| User state | First move | References |
|---|---|---|
| Has a full draft and wants a general check | Reconstruct the full logic chain | `references/chain-map.md`, `references/reviewer-red-flags.md` |
| Feels the proposal is scattered | Check section roles and scope drift | `references/section-role-check.md`, `references/scope-fit.md` |
| Literature review is heavy but the question is weak | Check whether basis leads to intervention | `references/literature-to-question.md`, `references/chain-map.md` |
| Content is rich but method is vague | Test evidence path and method fit | `references/evidence-method-fit.md` |
| Innovation, feasibility, and outcomes feel hollow | Check end-stage credibility | `references/innovation-feasibility-outcomes.md`, `references/reviewer-red-flags.md` |
| Needs revision advice, not just diagnosis | Convert findings into targeted repair moves | `references/repair-moves.md` |

### 3. Rebuild The Logic Chain

Summarize the proposal in one line per link:

- What exactly is being studied?
- Why is this problem worth studying now?
- What is missing or unstable in existing research?
- What new claim or intervention does this proposal make?
- Which research content pieces are necessary to answer that question?
- What materials, data, or methods can actually support those claims?
- Why is the project feasible for this applicant and schedule?
- What outcome is proportionate to the scope?

If any link cannot be stated clearly from the text, mark it as a logic gap.

### 4. Test The Eight Critical Joints

Check whether these joints hold:

1. Title -> Question: does the title match the real problem?
2. Question -> Literature: does the review lead to a genuine unresolved issue?
3. Literature -> Value: does the value come from the gap or only from policy rhetoric?
4. Value -> Content: do the research tasks actually answer the claimed problem?
5. Content -> Method: can the stated materials and methods support each task?
6. Method -> Innovation: is the innovation earned by the design rather than declared?
7. Feasibility -> Outcome: are the plan and expected results proportionate?
8. Whole proposal -> One sentence: can the proposal's logic be explained in one coherent sentence?

### 5. Apply The Bottleneck Logic

When the proposal follows standard application headings, interpret them through this practical chain:

- Basis or justification: define the pain point and explain why it matters now.
- Research status: identify the bottleneck in existing research or practice.
- Research content: propose the solution path for that bottleneck.
- Research focus: name the most critical part of that solution path.
- Research difficulty: identify the hardest point inside the focus.
- Research methods: explain how the bottleneck will actually be addressed.
- Feasibility: show what present conditions support execution.
- Innovation: explain how this solution advances beyond prior ones.
- Research foundation: show prior experience relevant to solving similar problems.
- References: signal the field standard, frontier awareness, and scholarly company the project keeps.

Use this chain especially when a draft sounds complete on the surface but still feels unconvincing. Often the problem is that one section fails to inherit the task of the previous one.

### 6. Prioritize Findings

Classify findings into:

- Fatal break: if not fixed, the proposal's core logic collapses.
- Major weakness: the proposal can stand, but review confidence drops sharply.
- Minor weakness: wording, emphasis, or ordering issue.

Do not overload the user with every possible suggestion. Surface the smallest number of changes that repairs the largest logic breaks.

### 7. Produce A Logic Review

Use this output shape:

```markdown
## Proposal Logic Diagnosis

**Overall verdict:** coherent / mostly coherent / partially coherent / structurally weak
**One-sentence logic chain:** ...

## Fatal Breaks
- ...

## Major Weaknesses
- ...

## Minor Weaknesses
- ...

## Best Repair Order
1. ...
2. ...
3. ...

## If Rewritten In One Sentence
...
```

If the user asks for revision help, convert the top findings into a tighter outline or section-by-section rewrite plan.

## Reference Cards

Load cards on demand:

- `references/chain-map.md`: use for reconstructing the proposal's core argument chain.
- `references/section-role-check.md`: use for checking whether each section is doing the right job.
- `references/literature-to-question.md`: use for testing whether the literature review produces a real question.
- `references/scope-fit.md`: use for detecting oversized topics, hidden subprojects, and title-content mismatch.
- `references/evidence-method-fit.md`: use for checking whether materials and methods can support the claims.
- `references/innovation-feasibility-outcomes.md`: use for testing whether innovation, schedule, and results are believable.
- `references/reviewer-red-flags.md`: use as the final skeptical gate from a reviewer's perspective.
- `references/repair-moves.md`: use when the user wants concrete revision actions rather than diagnosis only.

## Response Shape

Prefer this order:

1. Restated proposal chain.
2. Overall verdict.
3. Fatal breaks.
4. Major weaknesses.
5. Minor weaknesses.
6. Best repair order.
7. Optional rewrite direction.

Keep the tone direct, calm, and reviewer-aware. The goal is not to flatter the draft, but to help the user make the proposal easier to believe.
